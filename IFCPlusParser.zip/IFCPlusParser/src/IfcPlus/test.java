package IfcPlus;

import java.io.File;
import java.util.UUID;

import ifc4javatoolbox.ifc4.BOOLEAN;
import ifc4javatoolbox.ifc4.INTEGER;
import ifc4javatoolbox.ifc4.IfcActor;
import ifc4javatoolbox.ifc4.IfcBoolean;
import ifc4javatoolbox.ifc4.IfcDoor;
import ifc4javatoolbox.ifc4.IfcGateway;
import ifc4javatoolbox.ifc4.IfcGloballyUniqueId;
import ifc4javatoolbox.ifc4.IfcInteger;
import ifc4javatoolbox.ifc4.IfcLabel;
import ifc4javatoolbox.ifc4.IfcObject;
import ifc4javatoolbox.ifc4.IfcPerson;
import ifc4javatoolbox.ifc4.IfcPlusAgent;
import ifc4javatoolbox.ifc4.IfcPlusDevice;
import ifc4javatoolbox.ifc4.IfcPlusIoT;
import ifc4javatoolbox.ifc4.IfcPlusNetwork;
import ifc4javatoolbox.ifc4.IfcPlusRelIFC4;
import ifc4javatoolbox.ifc4.IfcPlusRelNetworkDevice;
import ifc4javatoolbox.ifc4.IfcPlusRelSensorData;
import ifc4javatoolbox.ifc4.IfcPlusRelSensorInterface;
import ifc4javatoolbox.ifc4.IfcPlusRelSensorMetadata;
import ifc4javatoolbox.ifc4.IfcPlusRelationship;
import ifc4javatoolbox.ifc4.IfcPlusSecurityNodeLora;
import ifc4javatoolbox.ifc4.IfcPlusSensorDataField;
import ifc4javatoolbox.ifc4.IfcPlusSensorDescriptor;
import ifc4javatoolbox.ifc4.IfcPlusSensorMetadata;
import ifc4javatoolbox.ifc4.IfcPlusServer;
import ifc4javatoolbox.ifc4.IfcPlusState;
import ifc4javatoolbox.ifc4.IfcPlusStateDoor;
import ifc4javatoolbox.ifc4.IfcPlusStateLamp;
import ifc4javatoolbox.ifc4.IfcPlusStateWindow;
import ifc4javatoolbox.ifc4.IfcPropertySet;
import ifc4javatoolbox.ifc4.IfcReal;
import ifc4javatoolbox.ifc4.IfcRelDefinesByProperties;
import ifc4javatoolbox.ifc4.IfcRelFillsElement;
import ifc4javatoolbox.ifc4.IfcRoot;
import ifc4javatoolbox.ifc4.IfcSensorType;
import ifc4javatoolbox.ifc4.IfcText;
import ifc4javatoolbox.ifc4.STRING;
import ifc4javatoolbox.ifcmodel.IfcModel;

public class test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IfcModel model = new IfcModel();
		File ifc = new File("C:\\ifc\\testnuevo.ifc");
		try {
			model.readStepFile(ifc);
			IfcActor lol = new IfcActor();
			model.addIfcObject(lol);
			//System.out.println("SIZE SENSORTYPE:"+model.getCollection(IfcSensorType.class).size());
			//IfcSensorType aux = model.getCollection(IfcSensorType.class).iterator().next();
			//System.out.println("GLOBAL ID:"+aux.getGlobalId() +"   "+aux.getName()	);
			//System.out.println("SIZE:"+model.getIfcObjects().size());
			//IfcPlusIoT gateway = model.getCollection(IfcPlusIoT.class).iterator().next();
			//System.out.println("PLUSIOT:"+gateway.getIoTID() +"      "+gateway.toString());
			//addNewIfcPlusSecurityNodeLora(model);
			//addNewIfcPlusAgent(model);
			IfcPlusSensorDescriptor desc  = addNewIfcSensorDescriptor(model);
			IfcPlusSensorMetadata meta = addNewIfcSensorMetadata(model);
			addNewIfcRelSensorMetadata(model, meta,desc);
			File newfile = new File("C:\\ifc\\ZZZNUEVO003.ifc");
			model.writeStepfile(newfile);
			
			///mirar la clase IFCPROPERTYSET
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	public static IfcPlusSensorDescriptor addNewIfcSensorDescriptor ( IfcModel model){
		IfcPlusSensorDescriptor te = new IfcPlusSensorDescriptor();
		IfcGloballyUniqueId uniqueid = new IfcGloballyUniqueId();
		uniqueid.setValue(new STRING("idnuevochulo12",false));
		te.setGlobalId(uniqueid);
		IfcText connector = new IfcText();
		connector.setValue(new STRING("802.15",false));
		te.setConnector(connector);
		
		IfcInteger fieldnumber  = new IfcInteger();
		fieldnumber.setValue(new INTEGER(48));
		te.setFieldnumber(fieldnumber);
		
		IfcText iotid = new IfcText();
		iotid.setValue(new STRING("IDCUSTOMstate2",false));
		te.setIoTID(iotid);
		
		IfcText separatortype  = new IfcText();
		separatortype.setValue(new STRING(";",false));
		te.setSeparatortype(separatortype);
		
		model.addIfcObject(te);
		return te;
	}
	
	public static void addNewIfcRelSensorMetadata (IfcModel model, 
			IfcPlusSensorMetadata metadata,
			IfcPlusSensorDescriptor descriptor){
		
		IfcPlusDevice device = new IfcPlusDevice();
		IfcText type = new IfcText();
		type.setValue(new STRING("sensor",false));
		device.setDevicetype(type);
		model.addIfcObject(device);;
		
		IfcPlusDevice device2 = new IfcPlusDevice();
		IfcText type2 = new IfcText();
		type2.setValue(new STRING("sensor2",false));
		device2.setDevicetype(type2);
		model.addIfcObject(device2);;
		
		IfcPlusNetwork network = new IfcPlusNetwork();
		network.setType(new IfcText(new STRING("point-to-point",false)));
		
		model.addIfcObject(network);
		
		IfcPlusRelNetworkDevice rel = new IfcPlusRelNetworkDevice();
		rel.addData(device);
		rel.addData(device2);
		rel.setNetwork(network);
		model.addIfcObject(rel);
		
		
		
		
		
		
		
		
	}
	public static IfcPlusSensorMetadata addNewIfcSensorMetadata( IfcModel model){
		IfcPlusSensorMetadata  te = new IfcPlusSensorMetadata ();
		
		IfcGloballyUniqueId uniqueid = new IfcGloballyUniqueId();
		uniqueid.setValue(new STRING("idnuevochulo1",false));
		te.setGlobalId(uniqueid);
		
		IfcText iotid = new IfcText();
		iotid.setValue(new STRING("IDCUSTOMstate1",false));
		te.setIoTID(iotid);
		
		IfcBoolean collect = new IfcBoolean();
		collect.setValue(new BOOLEAN(false));
		te.setCollectiondata(collect);
		
		IfcReal latitude = new IfcReal();
		latitude.setValue(154.5);
		te.setLatitude(latitude);
		
		IfcReal longitude = new IfcReal();
		longitude.setValue(15);
		te.setLongitude(longitude);
		
		IfcReal measuringinterval = new IfcReal();
		measuringinterval.setValue(0.31);
		te.setMeasuringinterval(measuringinterval);
		
		IfcBoolean mobile = new IfcBoolean();
		mobile.setValue(new BOOLEAN(true));
		te.setMobile(mobile);
		
		model.addIfcObject(te);
		return te;
	}
	
	public static void addNewIfcPlusAgent(IfcModel model){
		IfcPlusAgent te = new IfcPlusAgent();
		IfcText role = new IfcText();
		role.setValue(new STRING("manager hotel",false));
		
		te.setRole(role);
		
		IfcText token = new IfcText();
		token.setValue(new STRING("aojsidfjoaisjoid",false));
		te.setToken(token);
		
		IfcText userid = new IfcText();
		userid.setValue(new STRING("userid1",false));
		te.setUserid(userid);
		model.addIfcObject(te);;
	}
	
	public static void addNewIfcPlusSecurityNodeLora(IfcModel model){
		IfcPlusSecurityNodeLora te = new IfcPlusSecurityNodeLora();
		IfcText descri = new IfcText();
		descri.setValue(new STRING("description test lamp",false));
		te.setDescription(descri);
		
		IfcGloballyUniqueId uniqueid = new IfcGloballyUniqueId();
		UUID aux = UUID.randomUUID();
		uniqueid.setValue(new STRING(aux.toString(),false));
		te.setGlobalId(uniqueid);
		
		IfcLabel name = new IfcLabel();
		name.setValue(new STRING("NOMBRE NAME12",false));
		te.setName(name);
		
		IfcText iotid = new IfcText();
		iotid.setValue(new STRING("IDCUSTOMstate",false));
		te.setIoTID(iotid);
		
		IfcText appkey = new IfcText();
		appkey.setValue(new STRING("BAsjdu89a8u98a9sdfasdfasd",false));
		te.setAppkey(appkey);
		
		IfcText appskey = new IfcText();
		appskey.setValue(new STRING("BAsjasdfa233du89a8u98a9sdfasdfasd",false));
		te.setAppskey(appskey);
		
		IfcText newskey = new IfcText();
		newskey.setValue(new STRING("asdfu90asda90sd90",false));
		te.setNewskey(newskey);
		
		IfcInteger timestamp = new IfcInteger();
		timestamp.setValue(new INTEGER(1487336268));
		te.setTimestamp(timestamp);
		
		
		
		model.addIfcObject(te);
	}
	
	public static void addNewIfcPlusStateLamp(IfcModel model){
		IfcPlusStateLamp te = new IfcPlusStateLamp();
		IfcText descri = new IfcText();
		descri.setValue(new STRING("description test lamp",false));
		te.setDescription(descri);
		
		IfcGloballyUniqueId uniqueid = new IfcGloballyUniqueId();
		uniqueid.setValue(new STRING("idnuevochu12lo",false));
		te.setGlobalId(uniqueid);
		
		IfcLabel name = new IfcLabel();
		name.setValue(new STRING("NOMBRE NAME12",false));
		te.setName(name);
		
		IfcText iotid = new IfcText();
		iotid.setValue(new STRING("IDCUSTOMstate",false));
		te.setIoTID(iotid);
		
		IfcText state = new IfcText();
		state.setValue(new STRING("statedoor",false));
		te.setState(state);
		
		IfcInteger timestamp = new IfcInteger();
		timestamp.setValue(new INTEGER(1487336268));
		te.setTimestamp(timestamp);
		
		IfcText color = new IfcText();
		color.setValue(new STRING("white",false));
		te.setColor(color);
		
		IfcInteger intensity = new IfcInteger();
		intensity.setValue(54);
		te.setIntensity(intensity);
		
		IfcReal power = new IfcReal();
		power.setValue(14.6);
		te.setPower(power);
		
		IfcText typelight = new IfcText();
		typelight.setValue(new STRING("typo chula",false));
		te.setTypelight(typelight);
		
		model.addIfcObject(te);
	}
	
	
	public static void addNewIfcPlusStateWindow(IfcModel model){
		IfcPlusStateWindow te = new IfcPlusStateWindow();
		IfcText descri = new IfcText();
		descri.setValue(new STRING("description test window",false));
		te.setDescription(descri);
		
		IfcGloballyUniqueId uniqueid = new IfcGloballyUniqueId();
		uniqueid.setValue(new STRING("idnuevochulo",false));
		te.setGlobalId(uniqueid);
		
		IfcLabel name = new IfcLabel();
		name.setValue(new STRING("NOMBRE NAME",false));
		te.setName(name);
		
		IfcText iotid = new IfcText();
		iotid.setValue(new STRING("IDCUSTOMstate",false));
		te.setIoTID(iotid);
		
		IfcText state = new IfcText();
		state.setValue(new STRING("statedoor",false));
		te.setState(state);
		
		IfcInteger timestamp = new IfcInteger();
		timestamp.setValue(new INTEGER(1487336268));
		te.setTimestamp(timestamp);
		
		
		model.addIfcObject(te);
	}
	
	public static void addNewIfcPlusStateDoor(IfcModel model){
		IfcPlusStateDoor te = new IfcPlusStateDoor();
		IfcText descri = new IfcText();
		descri.setValue(new STRING("description test",false));
		te.setDescription(descri);
		
		IfcGloballyUniqueId uniqueid = new IfcGloballyUniqueId();
		uniqueid.setValue(new STRING("idnuevochulo",false));
		te.setGlobalId(uniqueid);
		
		IfcLabel name = new IfcLabel();
		name.setValue(new STRING("NOMBRE NAME",false));
		te.setName(name);
		
		IfcText iotid = new IfcText();
		iotid.setValue(new STRING("IDCUSTOMstate",false));
		te.setIoTID(iotid);
		
		IfcText state = new IfcText();
		state.setValue(new STRING("statedoor",false));
		te.setState(state);
		
		IfcInteger timestamp = new IfcInteger();
		timestamp.setValue(new INTEGER(1487336268));
		te.setTimestamp(timestamp);
		
		IfcText typ = new IfcText();
		typ.setValue(new STRING("entrance1",false));
		te.setTypeEntrance(typ);
		model.addIfcObject(te);
	}
	
	public static void addNewIfcPlusState(IfcModel model){
		IfcPlusState te = new IfcPlusState();
		IfcText descri = new IfcText();
		descri.setValue(new STRING("description test",false));
		te.setDescription(descri);
		
		IfcGloballyUniqueId uniqueid = new IfcGloballyUniqueId();
		uniqueid.setValue(new STRING("idnuevochulo",false));
		te.setGlobalId(uniqueid);
		
		IfcLabel name = new IfcLabel();
		name.setValue(new STRING("NOMBRE NAME",false));
		te.setName(name);
		
		IfcText iotid = new IfcText();
		iotid.setValue(new STRING("IDCUSTOMstate",false));
		te.setIoTID(iotid);
		
		IfcText state = new IfcText();
		state.setValue(new STRING("state",false));
		te.setState(state);
		
		IfcInteger timestamp = new IfcInteger();
		timestamp.setValue(new INTEGER(1487336268));
		te.setTimestamp(timestamp);
		
		model.addIfcObject(te);
		
		
		
	}
	
	public static void setNewItem(IfcModel model){
		IfcPlusIoT te = new IfcPlusIoT();
		//---
		IfcText descri = new IfcText();
		descri.setValue(new STRING("description test",false));
		te.setDescription(descri);
		
		IfcGloballyUniqueId uniqueid = new IfcGloballyUniqueId();
		uniqueid.setValue(new STRING("idnuevochulo",false));
		te.setGlobalId(uniqueid);
		
		IfcLabel name = new IfcLabel();
		name.setValue(new STRING("NOMBRE NAME",false));
		te.setName(name);
		
		IfcText iotid = new IfcText();
		iotid.setValue(new STRING("IDCUSTOM",false));
		te.setIoTID(iotid);
		model.addIfcObject(te);
		
		IfcGateway gateway = new IfcGateway();
		IfcText inter = new IfcText();
		inter.setValue(new STRING("interface",false));
		gateway.setInterface(inter);
		
		IfcText address = new IfcText();
		address.setValue(new STRING("address",false));
		gateway.setAddress(address);
		
		IfcText token = new IfcText();
		token.setValue(new STRING("token",false));
		gateway.setToken(token);
		
		gateway.setIot(te);
		model.addIfcObject(gateway);
		
	}

}
