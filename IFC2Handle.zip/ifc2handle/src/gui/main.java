package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by bihut on 15/06/17.
 */
public class main {

    private JPanel panel1;
    private JButton button1;
    //private JButton button1;

    public main() {
        /*button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });*/
    }
    public static void main(String[] args){
        JFrame frame = new JFrame("main");
        frame.setContentPane(new main().panel1);
        frame.setMinimumSize(new Dimension(400, 300));
        frame.setBounds(100,100,450,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }



}
