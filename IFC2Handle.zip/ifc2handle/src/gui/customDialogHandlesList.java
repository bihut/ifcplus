package gui;

import gui.util.HandleType;

import javax.swing.* ;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.InputMap;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRootPane;
import javax.swing.KeyStroke;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class customDialogHandlesList extends JDialog {

    private static final long serialVersionUID = 1L;
    //final ArrayList<String> list;
    public customDialogHandlesList(JFrame parent) {
        super(parent, "Handles Review/Edit");

        JPanel messagePane = new JPanel();
        TitledBorder titlecreatehandle;
        titlecreatehandle = BorderFactory.createTitledBorder("Handles List");

        messagePane.setBorder(titlecreatehandle);
        DefaultTableModel model = new DefaultTableModel();

        model.addColumn("Handles");
        model.addColumn("Type");



        JTable table = new JTable(model);
        TableColumn typecolum = table.getColumnModel().getColumn(1);
        typecolum.setCellEditor(new DefaultCellEditor(getIoTTypes()));
        table.setMinimumSize(messagePane.getMinimumSize());
        table.setMinimumSize(new Dimension(500,400));
        for(int i=0; i < IFC2Handle.handles.size();i++) {
            //System.out.println("AA:"+IFC2Handle.handles.get(i).toString());
            model.addRow(new Object[]{IFC2Handle.handles.get(i).getHandle(),Functions.getType(IFC2Handle.handles.get(i).getType())});
        }
        messagePane.add(new JScrollPane(table));
        messagePane.setMinimumSize(new Dimension(500,400));

        /*messagePane.add(new JLabel(message));
        // get content pane, which is usually the
        // Container of all the dialog's components.
        getContentPane().add(messagePane);

        // Create a button
        JPanel buttonPane = new JPanel();
        JButton button = new JButton("Close me");
        buttonPane.add(button);
        // set action listener on the button
        button.addActionListener(new MyActionListener());*/
        getContentPane().add(messagePane, BorderLayout.NORTH);
        table.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);
        JPanel options = new JPanel();
        JButton save = new JButton("Save");
        JButton cancel = new JButton("Cancel");
        options.add(save);
        options.add(cancel);
        save.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Object[][] aaa = getTableData(table);
                IFC2Handle.handles.clear();
                for (int i = 0 ; i < aaa.length ; i++){
                    HandleType t = new HandleType();
                    for (int j = 0 ; j < aaa[i].length ; j++) {
                       // System.out.println("DATA TABLE:"+aaa[i][j].toString() +"   "+i+"   "+j);
                       if(j==0)
                            t.setHandle(aaa[i][j].toString());
                        if(j==1)
                            t.setType(Functions.getIoTType(aaa[i][j].toString()));
                        //list.add(aaa[i][j].toString());
                    }
                    IFC2Handle.handles.add(t);
                }
                //System.out.println("GUARDADOS");
                for(int i=0; i <IFC2Handle.handles.size();i++){
                    System.out.println(IFC2Handle.handles.get(i).toString());
                }

                customDialogHandlesList.this.dispose();
            }
        });
        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                customDialogHandlesList.this.dispose();
            }
        });
        getContentPane().add(options,BorderLayout.SOUTH);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        pack();
        setVisible(true);
    }


    public JComboBox getIoTTypes(){
        JComboBox comboBox = new JComboBox();
        for(int i=0; i < Functions.TYPES_IOT.length;i++){
            comboBox.addItem(Functions.getType(Functions.TYPES_IOT[i]));
        }
        /*comboBox.addItem(Functions.getType());
        comboBox.addItem("Rowing");
        comboBox.addItem("Chasing toddlers");
        comboBox.addItem("Speed reading");
        comboBox.addItem("Teaching high school");
        comboBox.addItem("None");*/
       // sportColumn.setCellEditor(new DefaultCellEditor(comboBox));
        return comboBox;
    }
    public Object[][] getTableData (JTable table) {
        DefaultTableModel dtm = (DefaultTableModel) table.getModel();
        int nRow = dtm.getRowCount(), nCol = dtm.getColumnCount();
        Object[][] tableData = new Object[nRow][nCol];
        for (int i = 0 ; i < nRow ; i++)
            for (int j = 0 ; j < nCol ; j++)
                tableData[i][j] = dtm.getValueAt(i,j);
        return tableData;
    }
    // override the createRootPane inherited by the JDialog, to create the rootPane.
    // create functionality to close the window when "Escape" button is pressed
    public JRootPane createRootPane() {
        JRootPane rootPane = new JRootPane();
        KeyStroke stroke = KeyStroke.getKeyStroke("ESCAPE");
        Action action = new AbstractAction() {

            private static final long serialVersionUID = 1L;

            public void actionPerformed(ActionEvent e) {
                System.out.println("escaping..");
                setVisible(false);
                dispose();
            }
        };
        InputMap inputMap = rootPane.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
        inputMap.put(stroke, "ESCAPE");
        rootPane.getActionMap().put("ESCAPE", action);
        return rootPane;
    }

    // an action listener to be used when an action is performed
    // (e.g. button is pressed)
    class MyActionListener implements ActionListener {

        //close and dispose of the window.
        public void actionPerformed(ActionEvent e) {
            System.out.println("disposing the window..");
            setVisible(false);
            dispose();
        }
    }

    /*public static void main(String[] a) {

    }*/
}