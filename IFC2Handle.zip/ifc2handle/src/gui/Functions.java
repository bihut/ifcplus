package gui;

import java.math.BigInteger;

import java.net.URL;
import java.security.SecureRandom;


/**
 * Created by bihut on 18/07/17.
 */
public class Functions {
    public static String CREATORS="creators";
    public static String SUPERUSER="superuser";
    public static String TEMPLATES="templates";
    public static String TEMPLATES_OFFICIAL="official";
    public static String TEMPLATE_SENSOR="sensor";
    public static String TEMPLATE_ACTUATOR="actuator";
    public static String TEMPLATE_ENDNODELORA="endnodelora";
    public static String TEMPLATE_LIGHT="light";

    public static String SUPERUSER_PM="pm";
    public static String SUPERUSER_ISO="iso";
    public static String CREDENTIALS="credentials";
    public static String LORASERVER="loraserver";
    public static String MQTT="mqtt";
    public static String API_KEY="apikey";
    public static String ID="id";
    public static String TOKEN="token";
    public static String SUPERUSER_SUB="sub";
    public static String SUPERUSER_DEV="dev";
    public static String SUPERUSER_END="end";
    public static String TYPE_IOTSENSITIVE ="IOT_SENSITIVE";

    public static String TYPE_IOTTYPE="IOT_TYPE";
    public static int INDEX_SENSITIVE=700;
    public static int INDEX_HVSSLIST=200;
    public static int INDEX_IOTTYPE=802;
    public static int INDEX_IOTDATA=850;
    public static int INDEX_IOTSTRUCTURE=800;
    public static int INDEX_IOT_TEMPLATE_PARENT=950;

    public static String TYPE_IOTTEMPLATE_PARENT="IOT_TEMPLATE_PARENT";
    public static String TYPE_IOTTEMPLATE="IOT_TEMPLATE";
    public static String TYPE_IOTSTRUCTURE="IOT_STRUCTURE";
    public static String ROOT="root";
    public static int INDEX_IOT_TEMPLATESTATE=951;
    public static String TYPE_IOT_TEMPLATE_STATE="IOT_TEMPLATE_STATE";
    public static int INDEX_IOT_TEMPLATE_TYPE=952;
    public static String TYPE_IOT_TEMPLATE_TYPE="IOT_TEMPLATE_TYPE";
    public static int TYPE_IOT_TEMPLATE_OFFICIAL=0;
    public static int TYPE_IOT_TEMPLATE_NOOFFICIAL=1;

    public static int INDEX_IOT_TEMPLATE_PUBLIC=953;
    public static String TYPE_IOT_TEMPLATE_PUBLIC="IOT_TEMPLATE_PUBLIC";


    public static int IOT_TEMPLATE_NOPUBLIC=0;
    public static int IOT_TEMPLATE_PUBLIC=1;
    public static String USERS="users";
    public static int INDEX_TYPEUSER=777;
    public static String TYPE_IOTUSERTYPE ="IOT_USERTYPE";
    public static int TYPE_PM=0;
    public static String randomKey() {
        return new BigInteger(130, new SecureRandom()).toString(32);
    }

    public static String TYPE_IOTSPACEE="IOT_SPACE";
    public static String TYPE_IOTSENSOR ="IOT_SENSOR";
    public static String TYPE_IOTENDNODELORA="IOT_ENDNODELORA";
    public static String TYPE_IOTACTUATOR="IOT_ACTUATOR";
    public static String TYPE_IOTLIGHT="IOT_LIGHT";
    public static String TYPE_IOT_DATA="IOT_DATA";
    public static String[] TYPES_IOT ={TYPE_IOTSPACEE,TYPE_IOTSENSOR,TYPE_IOTENDNODELORA,
    TYPE_IOTACTUATOR,TYPE_IOTLIGHT,TYPE_IOT_DATA};
    public static boolean isValidURL(String urlString)
    {
        try
        {
            URL url = new URL(urlString);
            url.toURI();
            return true;
        } catch (Exception exception)
        {
            return false;
        }
    }
    public static String getType(String t){
        if(t.equals(TYPE_IOTSPACEE))
            return "Space";
        if(t.equals(TYPE_IOTSENSOR))
            return "Sensor";
        if(t.equals(TYPE_IOTENDNODELORA))
            return "End-Node LoRa";
        if(t.equals(TYPE_IOTACTUATOR))
            return "Actuator";
        if(t.equals(TYPE_IOTLIGHT))
            return "Light";
        if(t.equals(TYPE_IOT_DATA))
            return "Data";
        return "";
    }

    public static String getIoTType(String t){
        if(t.equals("Space"))
            return TYPE_IOTSPACEE;
        if(t.equals("Sensor"))
            return TYPE_IOTSENSOR;
        if(t.equals("End-Node LoRa"))
            return TYPE_IOTENDNODELORA;
        if(t.equals("Actuator"))
            return TYPE_IOTACTUATOR;
        if(t.equals("Light"))
            return TYPE_IOTLIGHT;
        if(t.equals("Data"))
            return TYPE_IOT_DATA;
        return "";
    }

    public static String PARAM_TEMPLATE_SENSOR="sensor";
    public static String PARAM_TEMPLATE_SENSORDATA="sensordata";
    public static String PARAM_TEMPLATE_ACTUATORDATA="actuatordata";
    public static String PARAM_TEMPLATE_ACTUATOR="actuator";
    public static String PARAM_TEMPLATE_ENDNODELORA ="endnodelora";
    public static String PARAM_TEMPLATE_ENDNODELORASECURITY ="endnodelorasecurity";
    public static String PARAM_TEMPLATE_DEVICECONTROLLER="endnode";
    public static String PARAM_TEMPLATE_LIGHT="light";
    public static String PARAM_TEMPLATE_RFID="rfid";
    public static String PARAM_TEMPLATE_NETWORK="network";
    public static String PARAM_TEMPLATE="getTemplate";
}
