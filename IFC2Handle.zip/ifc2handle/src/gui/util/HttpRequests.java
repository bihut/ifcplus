package gui.util;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;

/**
 * Created by bihut on 25/09/17.
 */
public class HttpRequests {
    private static String EVERY_APIDEVICES ="https://api.everynet.com/1.0.2/devices";
    private static String EVERY_APIPROJECT = "https://api.everynet.com/1.0.2/applications";
    public String GET(String url){

        //System.out.println("AQUI");
        String res=null;
        try{
            HttpGet get = new HttpGet("");

            get.addHeader("Authorization","");
            /*HttpResponse response = client.execute(get);
            System.out.println("STATUSCODE0:"+response.getStatusLine().getStatusCode());
            if(response.getStatusLine().getStatusCode()==200){
                res= EntityUtils.toString(response.getEntity());

            }
            response.getEntity().getContent().close();*/
        }catch(Exception e){
            System.out.println("ERROR:"+e.getMessage());
            e.printStackTrace();
            res = null;
        }

        return res;
    }
}
