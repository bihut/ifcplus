package gui.util;


import gui.Functions;

/**
 * Created by bihut on 29/08/17.
 */
public class HandleType {
    private String handle;
    private String type;

    public HandleType() {
        handle = "";
        type = Functions.TYPE_IOTSPACEE;
    }

    public String getHandle() {
        return handle;
    }

    public void setHandle(String handle) {
        this.handle = handle;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "HandleType{" +
                "handle='" + handle + '\'' +
                ", type='" + type + '\'' +
                '}';
    }
}
