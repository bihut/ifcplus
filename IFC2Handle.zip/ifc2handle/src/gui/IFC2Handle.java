package gui;

import MSiTBIM.HandleIFC.HandleIfcPlus2;
import MSiTBIM.HandleIFC.StaticReferences;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import gui.util.HandleType;
import http.HandleClient;
import ifc4javatoolbox.IoTUtil.JCheckBoxTree;
import ifc4javatoolbox.demo.IfcTreeView;
import ifc4javatoolbox.ifc4.*;
import ifc4javatoolbox.ifcmodel.IfcModel;
import ifc4javatoolbox.step.parser.util.ProgressEvent;
import ifc4javatoolbox.step.parser.util.StepParserProgressListener;

import jdk.nashorn.internal.parser.JSONParser;
import net.handle.hdllib.HandleException;
import net.handle.hdllib.ScanCallback;
import net.handle.hdllib.Util;
import net.handle.hdllib.ValueReference;
import org.apache.commons.io.FileUtils;
import org.apache.http.client.methods.HttpGet;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.text.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.function.Function;

/**
 * This is a demo application for the package
 * openifctools.com.ifcopenjavatoolbox<br>
 * <br><br>
 * Copyright: CC BY-NC-SA 3.0 DE (cc) 2013 Eike Tauscher and Michael Theiler<br><br>
 * The whole package including this class is licensed under<br>
 * <a rel='license' href='http://creativecommons.org/licenses/by-nc-sa/3.0/de/deed.en/'>
 * Creative Commons Attribution-Non-Commercial-Share Alike 3.0 Germany</a>.<br><br>
 * If you are using the package or parts of it in any commercial way, a commercial license is required.
 * Visit <a href='http://www.ifctoolsproject.com'>http://www.ifctoolsproject.com</a> for more information
 * or contact us directly: <a href='mailto:info@ifctoolsproject.com'>info@ifctoolsproject.com</a><br>
 */

///ipserver 128.16.13.30
public class IFC2Handle extends JFrame {
    private static final long serialVersionUID = 1L;
    private IfcModel ifcModel = null;
    private JProgressBar progressBar = null;
    private IfcTreeView treeView = null;
    private JTextPane infoPane = null;
    private JPanel handlePanel = null;
    private JScrollPane scrollPane = null;
    private JMenuItem saveItem = null;
    private JMenuItem renameProjectItem = null;

    ArrayList<String> NODELETE = new ArrayList<String>(Arrays.asList(MSiTBIM.Util.Util.getPropValues(StaticReferences.PROPERTIES_ADMINUSER)));

//	private URL openImageUrl = Thread
//			.currentThread()
//			.getContextClassLoader()
//			.getResource(
//					"openifctools/com/openifcjavatoolbox/icons/openFolder.png");
//	private URL editImageUrl = Thread.currentThread().getContextClassLoader()
//			.getResource("openifctools/com/openifcjavatoolbox/icons/edit.png");
//	private URL saveImageUrl = Thread.currentThread().getContextClassLoader()
//			.getResource("openifctools/com/openifcjavatoolbox/icons/save.png");
//	private URL aboutImageUrl = Thread.currentThread().getContextClassLoader()
//			.getResource("openifctools/com/openifcjavatoolbox/icons/about.png");

    /**
     * Constructs a new Structure Viewer object.
     */
    public IFC2Handle() {
        initComponents();
    }

    /**
     * initialize the application components
     */
    private void initComponents() {

        // Create new IfcModel
        ifcModel = new IfcModel();
        // init the frame
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());
        this.setSize(850, 430);
        // set MenuBar
        //this.setJMenuBar(getApplicationMenuBar());
        // set ProgressBar
        this.add(getApplicationProgressBar(), BorderLayout.SOUTH);
        // set TreeView


        this.add(panelThreeView(), BorderLayout.CENTER);
        // set InfoPane
        //this.add(getInfoPane(), BorderLayout.WEST);
        //set handlepanel
        this.add(getHandlePanel(), BorderLayout.EAST);
        // set frame to visible
        this.setVisible(true);

        this.setTitle("EBIS - IFC2Handle");
    }
    JLabel ifcinfo;
    public JPanel panelThreeView(){
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JButton loadIfc = new JButton("Load IFC file");
        ifcinfo = new JLabel();
        try{

            loadIfc.setIcon(new ImageIcon(this.getClass().getResource("img/ifcicon.png")));
        }catch(Exception e){

        }
        JPanel aux = new JPanel();
        aux.setLayout(new BoxLayout(aux, BoxLayout.X_AXIS));

        aux.add(loadIfc,BorderLayout.WEST);
        aux.add(ifcinfo,BorderLayout.EAST);
        aux.setBorder(BorderFactory.createEmptyBorder(5,0,5,0));
        loadIfc.setAlignmentX(Component.LEFT_ALIGNMENT);
        ifcinfo.setAlignmentX(Component.LEFT_ALIGNMENT);
        ifcinfo.setBorder(BorderFactory.createEmptyBorder(0,10,0,0));
        panel.add(aux);
        panel.add(treeView = new IfcTreeView());

        loadIfc.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                loadFile();
            }
        });

        return panel;
    }

    /*public void print(DefaultMutableTreeNode aNode) {
        String name = aNode.toString();
        int level = aNode.getLevel();
//128.16.71.251

        String placement = "";
        while (level > 0) {
            placement += ">";
            level--;
        }
        if (aNode.isLeaf()) {
            System.out.println(placement + name);
            return;
        }

        System.out.println(placement + "--- " + name + " ---");
        for (int i = 0; i < aNode.getChildCount(); i++) {
            print((DefaultMutableTreeNode) aNode.getChildAt(i));
        }
        System.out.println(placement + "+++ " + name + " +++");
    }*/

    String pathIFCPlusFile;
    ArrayList<IfcRoot> elements = new ArrayList<IfcRoot>();
    public static ArrayList<HandleType> handles = new ArrayList<HandleType>();
    JButton downloadIFCplus,generateifcfile ;
    JButton btncreatehandle,removehandlestructure;
    JButton btnreviewhandles;
    JTextField projectfield,server;
    HandleClient client;
    public static String API_HANDLES = "/api/handles";
    private JPanel getHandlePanel() {
        //ArayList<String> handles;
        ArrayList<Integer> ifcids;
        handlePanel = new JPanel();
        handlePanel.setLayout(new BoxLayout(handlePanel,BoxLayout.Y_AXIS));
        handlePanel.setMinimumSize(new Dimension(475, 400));
        handlePanel.setMaximumSize(new Dimension(475, 400));
        handlePanel.setPreferredSize(new Dimension(475, 400));
        this.setResizable(false);
        this.setPreferredSize(new Dimension(475,525));
        this.setMinimumSize(new Dimension(475,525));
        //IFC OPTIONS
        JPanel ifcoptions = new JPanel();
        ifcoptions.setMaximumSize(handlePanel.getPreferredSize());

        ifcoptions.setLayout(new BoxLayout(ifcoptions,BoxLayout.X_AXIS));
        ifcoptions.setAlignmentX(Component.CENTER_ALIGNMENT);
        generateifcfile = new JButton();

        downloadIFCplus = new JButton("Download IFC+ file");
        ifcoptions.add(generateifcfile);
        ifcoptions.add(downloadIFCplus);
        generateifcfile.setEnabled(false);
        downloadIFCplus.setAlignmentX(Component.RIGHT_ALIGNMENT);
        TitledBorder titleifc;
        titleifc = BorderFactory.createTitledBorder("IFC Plus Options");

        ifcoptions.setBorder(titleifc);
        downloadIFCplus.setEnabled(false);
        handlePanel.add(ifcoptions);

        //------------

        //PROJECT OPTIONS
        JPanel projectoptions = new JPanel();
        TitledBorder titleoptions = BorderFactory.createTitledBorder("Project Options");
        projectoptions.setBorder(titleoptions);
        projectoptions.setLayout(new GridLayout(4,2));
        handlePanel.add(projectoptions);
        projectfield = new JTextField();
        JTextField prefix = new JTextField();
        server = new JTextField();
        JLabel labelproject = new JLabel("Project");
        JLabel labelprefix = new JLabel("Prefix");
        JLabel labelserver = new JLabel("Server");
        projectoptions.add(labelproject);
        projectoptions.add(labelprefix);
        projectoptions.add(projectfield);
        projectoptions.add(prefix);
        projectoptions.add(labelserver);
        projectoptions.add(new JLabel());
        projectoptions.add(server);


        //Credentials
        JPanel credentials = new JPanel();
        TitledBorder titlecredentials = BorderFactory.createTitledBorder("Credentials");
        credentials.setBorder(titlecredentials);
        credentials.setLayout(new GridLayout(4,2));
        handlePanel.add(credentials);
        JTextField idpubnub = new JTextField();
        JPasswordField passpubnub = new JPasswordField();
        JPasswordField everyapikey = new JPasswordField();
        JLabel lblidpubnub = new JLabel("PubNub ID");
        JLabel lblpasspubnub = new JLabel("PubNub Password");
        JLabel lblevery = new JLabel("EveryNet API Key");

        credentials.add(lblidpubnub);
        credentials.add(lblpasspubnub);
        credentials.add(idpubnub);
        credentials.add(passpubnub);
        credentials.add(lblevery);
        credentials.add(new JLabel(""));
        credentials.add(everyapikey);

        //security handle
        JPanel securityhandle = new JPanel();
        TitledBorder titlesecurityhandle = BorderFactory.createTitledBorder("Handle Authorisation");
        securityhandle.setBorder(titlesecurityhandle);
        securityhandle.setLayout(new GridLayout(2,2));
        handlePanel.add(securityhandle);
        JTextField handleuser = new JTextField();
        JPasswordField handlepassword= new JPasswordField();
        JLabel labelhandleuser = new JLabel("Handle Admin");
        JLabel labelhandlepassword = new JLabel("Password/Secret Key");
        securityhandle.add(labelhandleuser);
        securityhandle.add(labelhandlepassword);
        securityhandle.add(handleuser);
        securityhandle.add(handlepassword);


        //pm info
        JPanel securitypm = new JPanel();
        TitledBorder titlesecuritypm = BorderFactory.createTitledBorder("PM Access");
        securitypm.setBorder(titlesecuritypm);
        securitypm.setLayout(new GridLayout(2,2));
        handlePanel.add(securitypm);
        JTextField pmuser= new JTextField();
        JPasswordField pmpassword= new JPasswordField();
        JLabel labelpmuser = new JLabel("PM Username");
        JLabel labelpmpassword = new JLabel("Password/Secret Key");
        securitypm.add(labelpmuser);
        securitypm.add(labelpmpassword);
        securitypm.add(pmuser);
        securitypm.add(pmpassword);

        //create handle
        JPanel createhandle = new JPanel();
        createhandle.setMaximumSize(handlePanel.getMaximumSize());
        createhandle.setAlignmentX(Component.CENTER_ALIGNMENT);
        createhandle.setLayout(new BoxLayout(createhandle,BoxLayout.X_AXIS));
        handlePanel.add(createhandle);
        btncreatehandle = new JButton("Create Handle");
        btnreviewhandles = new JButton("Review Handles");
        btncreatehandle.setHorizontalAlignment(SwingConstants.CENTER);
        removehandlestructure = new JButton("Remove Project");
        removehandlestructure.setHorizontalAlignment(SwingConstants.RIGHT);
        createhandle.add(btnreviewhandles);
        createhandle.add(btncreatehandle);
        createhandle.add(removehandlestructure);
        TitledBorder titlecreatehandle;
        titlecreatehandle = BorderFactory.createTitledBorder("Handle DO");
        createhandle.setBorder(titlecreatehandle);
        btncreatehandle.setEnabled(false);
        btnreviewhandles.setEnabled(false);
        //handlePanel.setEditable(false);


        btnreviewhandles.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //handles=getHandles();
                if(handles==null || handles.isEmpty()){
                    showOptionPane(handlePanel,"There are not handles to show");
                    return;
                }
                customDialogHandlesList dialog = new customDialogHandlesList(new JFrame());
                // set the size of the window
                dialog.setSize(650, 550);
            }
        });
        btncreatehandle.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String pm, pmpass,pubnubid,pubnubpass,everynetapikey;
                pm = pmpass = pubnubid = pubnubpass = everynetapikey = null;
                String pre = prefix.getText();
                String pro = projectfield.getText();
                boolean exist = checkIfExistProject(pre,pro);

                String admin = handleuser.getText();
                String password = handlepassword.getText();

                if (admin == null || admin.isEmpty() || password == null || password.isEmpty()) {
                    showOptionPane(handlePanel, "Administrator username or password must not be empty!");
                    return;
                }
                if (pre == null || pre.isEmpty()) {
                    showOptionPane(handlePanel, "PREFIX must not be empty!");
                    return;
                }

                if (pro == null || pro.isEmpty()) {
                    showOptionPane(handlePanel, "Project must not be empty!");
                    return;
                }
                String host = server.getText();
                if(host==null || host.isEmpty()){
                    showOptionPane(handlePanel, "Server/host must not be empty!");
                    return;
                }

                if(!Functions.isValidURL(host)){
                    showOptionPane(handlePanel, "The server URL is NOT valid");
                    return;
                }

                if(!exist){
                    pm = pmuser.getText();
                     pmpass = pmpassword.getText();
                    if (pm == null || pm.isEmpty() || pmpass == null || pmpass.isEmpty()) {
                        showOptionPane(handlePanel, "PM username or password must not be empty!");
                        return;
                    }

                    pubnubid = idpubnub.getText();
                    pubnubpass = passpubnub.getText();
                    if (pubnubid == null || pubnubid.isEmpty() || pubnubpass == null || pubnubpass.isEmpty()) {
                        showOptionPane(handlePanel, "PubNub ID or Password must not be empty!");
                        return;
                    }

                    everynetapikey = everyapikey.getText();
                    if (everynetapikey == null || everynetapikey.isEmpty()) {
                        showOptionPane(handlePanel, "EveryNet API KEY must not be empty!");
                        return;
                    }
                }
                try {
                    client = new HandleClient(host,pre,pro);
                    boolean auth=client.authenticateBySecretKey(API_HANDLES + "/" + pre + "/"+admin, pre + "/" + admin, password, 300);
                    //HandleIfcPlus2 lol = new HandleIfcPlus2(pre);
                    //boolean auth=lol.checkAuthenticationSecretKey(admin,password);
                    //String t=lol.getFullHandleSecretKey("ADMIN",admin,password,HandleIfcPlus2.TYPE_HSSECKEY);

                    if(auth){

                        boolean create = false;
                        boolean prevcreate=false;
                        if (exist) {
                            int reply = JOptionPane.showConfirmDialog(null, "Handle structure detected for the project ("+pro+"). Do you want to continue? (handles with the same identifier will be ignored)","Attention", JOptionPane.YES_NO_OPTION);
                            if (reply == JOptionPane.YES_OPTION) {
                                //JOptionPane.showMessageDialog(null, "HELLO");
                                create = true;
                                prevcreate = true;
                            }
                            else {
                                //JOptionPane.showMessageDialog(null, "GOODBYE");
                                //System.exit(0);
                            }
                        }else create=true;
                        if(create){
                            createHandleStructure(pro,pm,pmpass,pre,admin,password,pubnubid,pubnubpass,everynetapikey,prevcreate);
                        }

                        /*if(exist){
                            showOptionPane(handlePanel,"Handle structure detected, please remove it before create a new one");
                        }
                        else {
                        createHandleStructure(pro,pm,pmpass,pre,admin,password,pubnubid,pubnubpass,everynetapikey);

                        }*/
                    }
                    else showOptionPane(handlePanel,"Wrong username/password or host/server");
                } catch (Exception e1) {
                    e1.printStackTrace();
                }
                for(int i=0; i < handles.size();i++) {
                    //System.out.println(project.getText().toString()+"/"+handles.get(i));

                }
            }
        });
        removehandlestructure.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Thread t = new Thread(){
                  @Override
                    public void run(){

                      String admin = handleuser.getText();
                      String password = handlepassword.getText();
                      if(admin==null || admin.isEmpty() || password==null || password.isEmpty()){
                          showOptionPane(handlePanel,"Administrator username or password must not be empty!");
                          return;
                      }

                      String pre = prefix.getText();
                      if(pre==null || pre.isEmpty()){
                          showOptionPane(handlePanel,"PREFIX must not be empty!");
                          return;
                      }
                      String pro = projectfield.getText();
                      if(pro==null || pro.isEmpty()){
                          showOptionPane(handlePanel,"Project must not be empty!");
                          return;
                      }

                      String host = server.getText();
                      if(host==null || host.isEmpty()){
                          showOptionPane(handlePanel, "Server/host must not be empty!");
                          return;
                      }

                      if(!Functions.isValidURL(host)){
                          showOptionPane(handlePanel, "The server URL is NOT valid");
                          return;
                      }

//removeAllProject(pre,pro);
                      int dialogButton = JOptionPane.YES_NO_OPTION;
                      int dialogResult = JOptionPane.showConfirmDialog (null, "Would you like to remove the Handle structure under "+pre+"/"+pro+" ?","Warning",dialogButton);
                      if(dialogResult == JOptionPane.YES_OPTION){
                          //progressBar.setValue(50);
                          // Saving code here
                          //System.out.println("YES");


                          try {
                              progressBar.setValue(0);
                              progressBar.setStringPainted(true);
                              progressBar.setString("Authorising...");
                             // HandleIfcPlus2 lol = new HandleIfcPlus2(pre);
                              client = new HandleClient(host,pre,pro);
                              boolean auth=client.authenticateBySecretKey(API_HANDLES + "/" + pre + "/"+admin, pre + "/" + admin, password, 300);
                              //String t=lol.getFullHandleSecretKey("ADMIN",admin,password,HandleIfcPlus2.TYPE_HSSECKEY);
                              System.out.println("AUTH:" + auth);
                              if (!auth) {
                                  showOptionPane(handlePanel,"Wrong username/password");
                                  progressBar.setValue(0);
                                  progressBar.setStringPainted(false);
                                  progressBar.setString("");
                                  return;
                              }


                          /*progressBar.setValue(0);
                          progressBar.setStringPainted(true);
                          progressBar.setString("Getting handles");
                          ArrayList<String> hand=removeAllProject(pre,pro);

                          if(hand==null || hand.isEmpty())
                              showOptionPane(handlePanel,"Handle Structure is empty");
                          else {
                              //System.out.println("SIZE:"+hand.size());
                              boolean enter = false;
                              int increment = 100/hand.size();
                              NODELETE.clear();
                              NODELETE.add(pre+"/"+admin);


                              int deleted=0;
                              int progress = 0;
                              for (int i = 0; i < hand.size(); i++) {
                                  if(!NODELETE.contains(hand.get(i))) {
                                      enter = true;
                                      progress = progress+increment;
                                      progressBar.setValue(progress);
                                      //System.out.println("VALUE:" + progressBar.getValue());
                                      progressBar.setStringPainted(true);
                                      progressBar.setString("Deleting " + hand.get(i));
                                      boolean a=lol.deleteHandle(hand.get(i));

                                      progressBar.setString("Deleting " + hand.get(i)+"("+a+")");
                                      if (progress>= 100)
                                          progressBar.setValue(0);
                                      deleted++;
                                  }

                              }

                              if(enter){
                                showOptionPane(handlePanel,pre+"/"+pro+" structure deleted (DOs deleted:"+deleted+")");
                              }
                              else{
                                  showOptionPane(handlePanel,pre+"/"+pro+" structure is empty");
                              }


                          }
*/
                           String res=client.GETEbis("?removeProject=true&prefix="+pre+"&project="+pro);
                              System.out.println("RES:"+res);
                              JsonObject obj = new JsonParser().parse(res).getAsJsonObject();
                              if(obj.get("result").getAsBoolean()){
                                  showOptionPane(handlePanel,pre+"/"+pro+" structure deleted");
                              }
                              else{
                                  showOptionPane(handlePanel,"Error deleting "+pre+"/"+pro+" structure");
                              }

                          }catch(Exception e){
                              e.printStackTrace();
                              showOptionPane(handlePanel,"Error deleting "+pre+"/"+pro+" structure");
                          }
                          progressBar.setValue(0);
                          progressBar.setStringPainted(false);
                          progressBar.setString("");
                      }
                      else{
                          //System.out.println("NO");
                      }
                  }
                };
                t.start();

            }
        });

        generateifcfile.setText("Generate IFC+ File");
        generateifcfile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generateIfcPlusFile();
                /*if(res){
                    downloadIFCplus.setEnabled(true);
                    btnreviewhandles.setEnabled(true);
                    btncreatehandle.setEnabled(true);
                    projectfield.setText(IFC2Handle.this.project);;
                }*/
                //IfcPlusIoT aux = new IfcPlusIoT();
                //IfcPlusRelIFC4 rel = new IfcPlusRelIFC4();

            }
        });

        downloadIFCplus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Specify a file to save");

                int userSelection = fileChooser.showSaveDialog(handlePanel);

                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File fileToSave = fileChooser.getSelectedFile();
                    //System.out.println("Save as file: " + fileToSave.getAbsolutePath());
                    try {
                        FileUtils.writeStringToFile(fileToSave,FileUtils.readFileToString(new File(pathIFCPlusFile),"UTF-8"),"UTF-8");
                    } catch (IOException e1) {
                        e1.printStackTrace();
                    }
                }
            }
        });

        //handlePanel.add(generateifcfile,BorderLayout.NORTH);
        //handlePanel.add(downloadIFCplus,BorderLayout.NORTH);

       // handlePanel.add(projectoptions);
       // handlePanel.add(new JButton("asdads"),BorderLayout.WEST);

        //handlePanel.setViewportView(infoPane);
        return handlePanel;
    }


    public boolean generateIfcPlusFile(){


        new Thread(new Runnable() {

            @Override
            public void run() {
                long startTime = System.currentTimeMillis();
                boolean res=true;
                progressBar.setValue(0);
                //IFC2Handle.this.setTitle(file.getName());
                progressBar.setStringPainted(true);

                progressBar.setString("Getting IFC Global Identifiers");
                pathIFCPlusFile = null;
                elements = getIFCIds();
                progressBar.setValue(10);
                if(elements==null|| elements.isEmpty()){
                    showOptionPane(handlePanel,"There are not sensitive elements selected");
                    progressBar.setValue(0);
                    //IFC2Handle.this.setTitle(file.getName());
                    progressBar.setStringPainted(false);
                    return;
                }
                progressBar.setValue(100);
                progressBar.setString("Constructing IFCPlus file");
                progressBar.setValue(0);
                int progress =100/elements.size();

                for (int i = 0; i < elements.size(); i++) {
                    IfcPlusIoT aux = new IfcPlusIoT();
                    STRING aa = new STRING();
                    aa.setDecodedValue(UUID.randomUUID().toString());
                    aux.setIoTID(new IfcText(aa));
                    ifcModel.addIfcObject(aux);
                    IfcPlusRelIFC4 rel = new IfcPlusRelIFC4();
                    rel.setPlus(aux);
                    rel.setObject(elements.get(i));
                    ifcModel.addIfcObject(rel);
                    progressBar.setValue(progressBar.getValue()+progress);
                }
                System.out.println("AQUI:"+progressBar.getString());
                progressBar.setValue(50);
                progressBar.setString("Setting schema");
                ifcModel.setSchema("IFCPlus");

                progressBar.setValue(100);
                progressBar.setString("Generating IFCPlus File");
                try {
                    String path = System.getProperty("java.io.tmpdir");
                    pathIFCPlusFile = path + "/" + System.currentTimeMillis() + ".ifc";
                    FileUtils.writeStringToFile(new File(pathIFCPlusFile), ifcModel.getModelAsText(), "UTF-8");

                    res=true;
                } catch (Exception e1) {
                    e1.printStackTrace();
                    res=false;
                }

                handles=getHandles();
                progressBar.setValue(0);
                //IFC2Handle.this.setTitle(file.getName());
                if(res) {
                    progressBar.setStringPainted(false);
                    downloadIFCplus.setEnabled(true);
                    btnreviewhandles.setEnabled(true);
                    btncreatehandle.setEnabled(true);
                    projectfield.setText(IFC2Handle.this.project);

                }
            }
        }).start();
        /*
        pathIFCPlusFile = null;
        elements = getIFCIds();
        boolean res=true;
        if(elements==null|| elements.isEmpty()){
            showOptionPane(handlePanel,"There are not sensitive elements selected");
            return false;
        }
        for (int i = 0; i < elements.size(); i++) {
            IfcPlusIoT aux = new IfcPlusIoT();
            STRING aa = new STRING();
            aa.setDecodedValue(UUID.randomUUID().toString());
            aux.setIoTID(new IfcText(aa));
            ifcModel.addIfcObject(aux);
            IfcPlusRelIFC4 rel = new IfcPlusRelIFC4();
            rel.setPlus(aux);
            rel.setObject(elements.get(i));
            ifcModel.addIfcObject(rel);
        }
        ifcModel.setSchema("IFCPlus");

        try {
            String path = System.getProperty("java.io.tmpdir");
            pathIFCPlusFile = path + "/" + System.currentTimeMillis() + ".ifc";
            FileUtils.writeStringToFile(new File(pathIFCPlusFile), ifcModel.getModelAsText(), "UTF-8");
            res=true;

        } catch (Exception e1) {
            e1.printStackTrace();
            res=false;
        }

        if(!res)
            return res;
        handles=getHandles();
        try {
            //String aux = handles.get(0);

            res=true;
        }catch(Exception e0){
res = false;
        }
        return res;*/
        return true;
    }

    public void showOptionPane(JPanel panel,String message){
        JOptionPane.showMessageDialog(panel, message);
    }

    public ArrayList<String> removeAllProject(String prefix,String pro){
        try{

            HandleIfcPlus2 aux = new HandleIfcPlus2(prefix);
           return aux.listHandles();
        }catch(Exception e){

        }
        return null;
    }
    public boolean checkIfExistProject(String prefix,String project){
        try{
            HandleIfcPlus2 aux = new HandleIfcPlus2(prefix);
            return aux.checkHandleExist(project+"/superuser/pm");
        }catch(Exception e){

        }
        return false;
    }

    public boolean checkHandleExist(String prefix, String handle){
        try{
            HandleIfcPlus2 aux = new HandleIfcPlus2(prefix);
            //handle = handle.replace(prefix+"/","");
            return aux.checkHandleExist(handle);
        }catch(Exception e){

        }
        return false;
    }
    public String getEveryNetApiKEY(String id,String password){
        try {

        }catch(Exception e){

        }
        return null;

    }
    public boolean createHandleStructure(String project,String pm,String pmpassword,String prefix,String adminuser,String adminpassword,String pubnubid,String pubnubpass,String everyapikey,boolean prevcreated){


        Thread t = new Thread(){
          @Override
            public void run(){
              try {


                  progressBar.setValue(0);
                  progressBar.setStringPainted(true);
                  progressBar.setString("Creating Handle structure under " + prefix + "/" + project);
                  HandleIfcPlus2 aux = new HandleIfcPlus2(prefix);


                  //create the prefix/creators
                  //String handleUserId, String password, String values, int valuesindex,String type
                  boolean res = true;
                  if (!prevcreated) {
                      progressBar.setValue(15);
                      progressBar.setStringPainted(true);
                      progressBar.setString("Creating creators..");

                      //res &= aux.createHandleSecretKey(Functions.CREATORS, Functions.randomKey(), "", 400, "IOT_EBIS");
                      JsonArray values = new JsonArray();
                      values.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+Functions.CREATORS,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+Functions.SUPERUSER+"/"+ Functions.SUPERUSER_PM,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+Functions.SUPERUSER+"/"+ Functions.SUPERUSER_ISO,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                      JsonArray array = new JsonArray();
                      JsonObject obj = client.getJSONValueByTypeIndex(prefix+"/"+Functions.CREATORS,400,"IOT_EBIS","",null);
                      array.add(obj);
                      res&=client.createHandleIFC2HANDLE(prefix+"/"+Functions.CREATORS,values,Functions.randomKey(),adminuser,array);

                  }


                  //create 0.NA/prefix
                  //-------------
                  if (!prevcreated) {
                      progressBar.setValue(30);
                      progressBar.setStringPainted(true);
                      progressBar.setString("Creating NA");

                      /*ValueReference references = new ValueReference();
                      references.handle = Util.encodeString(prefix + "/" + Functions.CREATORS);
                      references.index = HandleIfcPlus2.HSVLIST_RECORD_INDEX;
                      res &= aux.createHandleSecretKeyNA(prefix, Functions.randomKey(), "", 400, "IOT_EBIS", new ValueReference[]{references});*/

                      JsonArray values = new JsonArray();
                      values.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+Functions.CREATORS,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST("0.NA/"+prefix,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                      //JsonObject admin =  client.getJSONValueADMIN(103,"0.NA/"+prefix,300,"111111110011");

                      res&=client.createHandleIFC2HANDLENA(values,Functions.randomKey(),adminuser);
                  }
                  res = true;


                  //create project
                  if (!prevcreated) {
                      progressBar.setValue(30);
                      progressBar.setStringPainted(true);
                      progressBar.setString("Creating project..");

                      JsonArray values = new JsonArray();
                      values.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      JsonArray array = new JsonArray();
                      JsonObject obj = client.getJSONValueByTypeIndex(prefix+"/"+Functions.CREATORS,400,"IOT_EBIS","",null);
                      array.add(obj);
                      res&=client.createHandleIFC2HANDLE(prefix+"/"+project,values,Functions.randomKey(),adminuser,array);
                      //res &= aux.createHandleSecretKey(project, Functions.randomKey(), "", 400, "IOT_EBIS");

                  }


                  //create the prefix/project/superuser/pm & prefix/project/superuser/iso
                  if (!prevcreated) {

                      progressBar.setValue(45);
                      progressBar.setStringPainted(true);
                      progressBar.setString("Creating superusers (pm and iso)..");

                      JsonArray values = new JsonArray();
                      values.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_PM,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.USERS+"/"+pm,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      JsonArray array = new JsonArray();
                      JsonObject obj = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.SUPERUSER+"/"+Functions.SUPERUSER_PM,400,"IOT_EBIS","",null);
                      array.add(obj);
                      res&=client.createHandleIFC2HANDLE(prefix+"/"+project+"/"+Functions.SUPERUSER+"/"+Functions.SUPERUSER_PM,values,Functions.randomKey(),adminuser,array);

                      values = new JsonArray();
                      values.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_ISO,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_PM,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                       array = new JsonArray();
                       obj = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.SUPERUSER+"/"+Functions.SUPERUSER_ISO,400,"IOT_EBIS","",null);
                      array.add(obj);
                      res&=client.createHandleIFC2HANDLE(prefix+"/"+project+"/"+Functions.SUPERUSER+"/"+Functions.SUPERUSER_ISO,values,Functions.randomKey(),adminuser,array);


                      /*res &= aux.createHandleSecretKey(project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_PM, Functions.randomKey(), "", 400, "IOT_EBIS");
                      res &= aux.createHandleSecretKey(project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_ISO, Functions.randomKey(), "", 400, "IOT_EBIS");
                      res &= aux.addHSVLISTHandle(project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_ISO, project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_PM, HandleIfcPlus2.HSVLIST_RECORD_INDEX);
                      res &= aux.addHSVLISTHandle(Functions.CREATORS, project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_PM, Functions.INDEX_HVSSLIST);
                      res &= aux.addHSVLISTHandle(Functions.CREATORS, project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_ISO, Functions.INDEX_HVSSLIST);*/

                  }
                  //create the prefix/project/users/<pm>
                  if (!prevcreated){
                      progressBar.setValue(60);
                        progressBar.setStringPainted(true);
                        progressBar.setString("Creating user:" + pm);


                      JsonArray values = new JsonArray();
                      values.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.USERS+"/"+pm,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      JsonArray array = new JsonArray();
                      JsonObject obj = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.SUPERUSER+"/"+Functions.SUPERUSER_PM,Functions.INDEX_TYPEUSER,Functions.TYPE_IOTUSERTYPE,Functions.TYPE_PM+"",null);
                      array.add(obj);
                      res&=client.createHandleIFC2HANDLE(prefix+"/"+project+"/"+Functions.USERS+"/"+pm,values,pmpassword,adminuser,array);

                      //res &= aux.createHandleSecretKey(project + "/" + Functions.USERS + "/" + pm, pmpassword, Functions.TYPE_PM + "", Functions.INDEX_TYPEUSER, Functions.TYPE_IOTUSERTYPE);
                  //res &= aux.addHSVLISTHandle(project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_PM, project + "/" + Functions.USERS + "/" + pm);
                    }

                  if(!prevcreated) {

                      //create credentials
                      progressBar.setValue(70);
                      progressBar.setStringPainted(true);
                      progressBar.setString("Creating LoRa server and MQTT credentials");

                      //create LoRa server (EveryNet)

                      JsonArray values = new JsonArray();
                      values.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_PM,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_ISO,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                      JsonArray array = new JsonArray();
                      JsonObject obj = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.LORASERVER+"/"+ Functions.API_KEY,Functions.INDEX_IOTDATA,Functions.TYPE_IOT_DATA,everyapikey,null);
                      JsonObject obj2 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.LORASERVER+"/"+ Functions.API_KEY,Functions.INDEX_SENSITIVE,Functions.TYPE_IOTSENSITIVE,"1",null);
                      JsonObject obj3 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.LORASERVER+"/"+ Functions.API_KEY,Functions.INDEX_IOTTYPE,Functions.TYPE_IOTTYPE,Functions.TYPE_IOT_DATA,null);
                      array.add(obj);
                      array.add(obj2);
                      array.add(obj3);
                      res&=client.createHandleIFC2HANDLE(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.LORASERVER+"/"+ Functions.API_KEY,values,Functions.randomKey(),adminuser,array);

                      /*ValueReference[] reference0 = new ValueReference[2];
                      reference0[0] = new ValueReference();
                      reference0[0].handle = Util.encodeString(prefix + "/" + project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_PM);
                      reference0[0].index = HandleIfcPlus2.HSVLIST_RECORD_INDEX;
                      reference0[1] = new ValueReference();
                      reference0[1].handle = Util.encodeString(prefix + "/" + project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_ISO);
                      reference0[1].index = HandleIfcPlus2.HSVLIST_RECORD_INDEX;

                      res &= aux.createHandleSecretKey(project + "/" + Functions.CREDENTIALS + "/" + Functions.LORASERVER + "/" + Functions.API_KEY, Functions.randomKey(), everyapikey,
                              Functions.INDEX_IOTDATA, Functions.TYPE_IOT_DATA, reference0);
                      res &= aux.addIndexExistingHandle(project + "/" + Functions.CREDENTIALS + "/" + Functions.LORASERVER + "/" + Functions.API_KEY, Functions.TYPE_IOTSENSITIVE, "1".getBytes("UTF-8"), Functions.INDEX_SENSITIVE);
                      res &= aux.addIndexExistingHandle(project + "/" + Functions.CREDENTIALS + "/" + Functions.LORASERVER + "/" + Functions.API_KEY, Functions.TYPE_IOTTYPE, Functions.TYPE_IOT_DATA.getBytes("UTF-8"), Functions.INDEX_IOTTYPE);*/

                  }

                  if(!prevcreated) {
                      //create MQTT

                      JsonArray values = new JsonArray();
                      values.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_PM,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                      values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_ISO,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                      JsonArray array = new JsonArray();
                      JsonObject obj1 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.MQTT+"/"+ Functions.ID,Functions.INDEX_IOTDATA,Functions.TYPE_IOT_DATA,pubnubid,null);
                      JsonObject obj2 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.MQTT+"/"+ Functions.ID,Functions.INDEX_SENSITIVE,Functions.TYPE_IOTSENSITIVE,"1",null);
                      JsonObject obj3 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.MQTT+"/"+ Functions.ID,Functions.INDEX_IOTTYPE,Functions.TYPE_IOTTYPE,Functions.TYPE_IOT_DATA,null);
                        array.add(obj1);
                      array.add(obj2);
                      array.add(obj3);
                      res&=client.createHandleIFC2HANDLE(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.MQTT+"/"+ Functions.ID,values,Functions.randomKey(),adminuser,array);


                      /*ValueReference[] reference00 = new ValueReference[2];
                      reference00[0] = new ValueReference();
                      reference00[0].handle = Util.encodeString(prefix + "/" + project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_PM);
                      reference00[0].index = HandleIfcPlus2.HSVLIST_RECORD_INDEX;
                      reference00[1] = new ValueReference();
                      reference00[1].handle = Util.encodeString(prefix + "/" + project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_ISO);
                      reference00[1].index = HandleIfcPlus2.HSVLIST_RECORD_INDEX;
                      res &= aux.createHandleSecretKey(project + "/" + Functions.CREDENTIALS + "/" + Functions.MQTT + "/" + Functions.ID, Functions.randomKey(), pubnubid,
                              Functions.INDEX_IOTDATA, Functions.TYPE_IOT_DATA, reference00);
                      res &= aux.addIndexExistingHandle(project + "/" + Functions.CREDENTIALS + "/" + Functions.MQTT + "/" + Functions.ID, Functions.TYPE_IOTSENSITIVE, "1".getBytes("UTF-8"), Functions.INDEX_SENSITIVE);
                      res &= aux.addIndexExistingHandle(project + "/" + Functions.CREDENTIALS + "/" + Functions.MQTT + "/" + Functions.ID, Functions.TYPE_IOTTYPE, Functions.TYPE_IOT_DATA.getBytes("UTF-8"), Functions.INDEX_IOTTYPE);


                      ValueReference[] reference000 = new ValueReference[2];
                      reference000[0] = new ValueReference();
                      reference000[0].handle = Util.encodeString(prefix + "/" + project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_PM);
                      reference000[0].index = HandleIfcPlus2.HSVLIST_RECORD_INDEX;
                      reference000[1] = new ValueReference();
                      reference000[1].handle = Util.encodeString(prefix + "/" + project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_ISO);
                      reference000[1].index = HandleIfcPlus2.HSVLIST_RECORD_INDEX;
                      res &= aux.createHandleSecretKey(project + "/" + Functions.CREDENTIALS + "/" + Functions.MQTT + "/" + Functions.TOKEN, Functions.randomKey(), pubnubpass,
                              Functions.INDEX_IOTDATA, Functions.TYPE_IOT_DATA, reference000);
                      res &= aux.addIndexExistingHandle(project + "/" + Functions.CREDENTIALS + "/" + Functions.MQTT + "/" + Functions.TOKEN, Functions.TYPE_IOTSENSITIVE, "1".getBytes("UTF-8"), Functions.INDEX_SENSITIVE);
                      res &= aux.addIndexExistingHandle(project + "/" + Functions.CREDENTIALS + "/" + Functions.MQTT + "/" + Functions.TOKEN, Functions.TYPE_IOTTYPE, Functions.TYPE_IOT_DATA.getBytes("UTF-8"), Functions.INDEX_IOTTYPE);*/

                      JsonArray values0 = new JsonArray();
                      values0.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                      values0.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_PM,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                      values0.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_ISO,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                      JsonArray array0 = new JsonArray();
                      JsonObject obj10 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.MQTT+"/"+ Functions.TOKEN,Functions.INDEX_IOTDATA,Functions.TYPE_IOT_DATA,pubnubpass,null);
                      JsonObject obj20 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.MQTT+"/"+ Functions.TOKEN,Functions.INDEX_SENSITIVE,Functions.TYPE_IOTSENSITIVE,"1",null);
                      JsonObject obj30 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.MQTT+"/"+ Functions.TOKEN,Functions.INDEX_IOTTYPE,Functions.TYPE_IOTTYPE,Functions.TYPE_IOT_DATA,null);
                        array0.add(obj10);
                      array0.add(obj20);
                      array0.add(obj30);
                      res&=client.createHandleIFC2HANDLE(prefix+"/"+project+"/"+Functions.CREDENTIALS+"/"+Functions.MQTT+"/"+ Functions.TOKEN,values0,Functions.randomKey(),adminuser,array0);



                  }

                  //creating templates default templates
                  progressBar.setValue(75);
                  progressBar.setStringPainted(true);
                  progressBar.setString("Creating templates...");
                  String val=client.GETTemplate(Functions.TEMPLATE_SENSOR);
                  JsonParser parser = new JsonParser();
                  JsonObject obj = parser.parse(val).getAsJsonObject();
                  obj.addProperty("parent","root");
                  res&=createTemplate(Functions.TEMPLATE_SENSOR,client,prefix,project,adminuser,obj.toString());
                  val=client.GETTemplate(Functions.TEMPLATE_ACTUATOR);

                  obj = parser.parse(val).getAsJsonObject();
                  obj.addProperty("parent","root");
                  res&=createTemplate(Functions.TEMPLATE_ACTUATOR,client,prefix,project,adminuser,obj.toString());

                  val=client.GETTemplate(Functions.TEMPLATE_ENDNODELORA);

                  obj = parser.parse(val).getAsJsonObject();
                  obj.addProperty("parent","root");
                  res&=createTemplate(Functions.TEMPLATE_ENDNODELORA,client,prefix,project,adminuser,obj.toString());
                  val=client.GETTemplate(Functions.TEMPLATE_LIGHT);
                  obj = parser.parse(val).getAsJsonObject();
                  obj.addProperty("parent","root");
                  res&=createTemplate(Functions.TEMPLATE_LIGHT,client,prefix,project,adminuser,obj.toString());
                  /*if(!prevcreated){

                  }*/

                  //sensor


                  //create the different handles

                  int increment = (100-progressBar.getValue())/handles.size()-3;
                  for(int i=0; i < handles.size();i++){
                      progressBar.setValue(progressBar.getValue()+increment);
                      progressBar.setStringPainted(true);
                      if(!checkHandleExist(prefix,handles.get(i).getHandle())) {
                          System.out.println("NO EXISTE, SE CREA:"+handles.get(i).getHandle());
                          progressBar.setString("Creating handle:" + handles.get(i).getHandle() + "(Type:" + Functions.getType(handles.get(i).getType()) + ")");

                          JsonArray values = new JsonArray();
                          values.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
                          values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_PM,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                          values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_ISO,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
                          JsonArray array = new JsonArray();
                          //JsonObject obj1 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+ handles.get(i).getHandle(),Functions.INDEX_IOTDATA,Functions.TYPE_IOT_DATA,pubnubid);
                          JsonObject obj2 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+handles.get(i).getHandle(),Functions.INDEX_SENSITIVE,Functions.TYPE_IOTSENSITIVE,"1",null);
                          JsonObject obj3 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+handles.get(i).getHandle(),Functions.INDEX_IOTTYPE,Functions.TYPE_IOTTYPE,handles.get(i).getType(),null);
                         // array.add(obj1);
                          array.add(obj2);
                          array.add(obj3);
                          res&=client.createHandleIFC2HANDLE(prefix+"/"+project+"/"+handles.get(i).getHandle(),values,Functions.randomKey(),adminuser,array);


                          /*ValueReference[] reference = new ValueReference[2];
                          reference[0] = new ValueReference();
                          reference[0].handle = Util.encodeString(prefix + "/" + project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_PM);
                          reference[0].index = HandleIfcPlus2.HSVLIST_RECORD_INDEX;
                          reference[1] = new ValueReference();
                          reference[1].handle = Util.encodeString(prefix + "/" + project + "/" + Functions.SUPERUSER + "/" + Functions.SUPERUSER_ISO);
                          reference[1].index = HandleIfcPlus2.HSVLIST_RECORD_INDEX;
                          res &= aux.createHandleSecretKey(project + "/" + handles.get(i).getHandle(), Functions.randomKey(), "1",
                                  Functions.INDEX_SENSITIVE, Functions.TYPE_IOTSENSITIVE, reference);
                          //add type iot_space
                          res &= aux.addIndexExistingHandle(project + "/" + handles.get(i).getHandle(), Functions.TYPE_IOTTYPE, handles.get(i).getType().getBytes("UTF-8"), Functions.INDEX_IOTTYPE);*/

                      }
                      else{
                          System.out.println("YA EXISTE: "+handles.get(i).getHandle());
                      }
                  }

                  progressBar.setValue(0);
                  progressBar.setStringPainted(false);
                  progressBar.setString("");

                  if(res) {
                      showOptionPane(handlePanel, "Handle Structure Created");
                  }
                  else{
                      showOptionPane(handlePanel,"Error creating Handle Structure, please remove it before try it again");
                  }
              } catch (Exception e) {
                  e.printStackTrace();
              }

          }
        };

        t.start();

        return true;
    }

    private boolean createTemplate(String template,HandleClient client,String prefix,String project,String adminuser,String value){
        try{

            JsonArray values = new JsonArray();
            values.add(client.getDefaultHSVLIST(prefix+"/"+adminuser,HandleIfcPlus2.HSSECKEY_RECORD_INDEX));
            values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_PM,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
            values.add(client.getDefaultHSVLIST(prefix+"/"+project+"/"+ Functions.SUPERUSER+"/"+Functions.SUPERUSER_ISO,HandleIfcPlus2.HSVLIST_RECORD_INDEX));
            JsonArray array = new JsonArray();
            JsonObject obj1 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.TEMPLATES+"/"+Functions.TEMPLATES_OFFICIAL+"/"+ template,Functions.INDEX_IOTSTRUCTURE,Functions.TYPE_IOTSTRUCTURE,value,"1110");
            JsonObject obj2 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.TEMPLATES+"/"+Functions.TEMPLATES_OFFICIAL+"/"+ template,Functions.INDEX_IOTTYPE,Functions.TYPE_IOTTEMPLATE,Functions.TYPE_IOTTEMPLATE,null);
            JsonObject obj3 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.TEMPLATES+"/"+Functions.TEMPLATES_OFFICIAL+"/"+ template,Functions.INDEX_IOT_TEMPLATE_PARENT,Functions.TYPE_IOTTEMPLATE_PARENT,Functions.ROOT,null);
            JsonObject obj5 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.TEMPLATES+"/"+Functions.TEMPLATES_OFFICIAL+"/"+ template,Functions.INDEX_IOT_TEMPLATE_TYPE,Functions.TYPE_IOT_TEMPLATE_TYPE,Functions.TYPE_IOT_TEMPLATE_OFFICIAL+"",null);
            JsonObject obj6 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.TEMPLATES+"/"+Functions.TEMPLATES_OFFICIAL+"/"+ template,Functions.INDEX_IOT_TEMPLATE_PUBLIC,Functions.TYPE_IOT_TEMPLATE_PUBLIC,Functions.IOT_TEMPLATE_PUBLIC+"",null);
            JsonObject state = new JsonObject();
            state.addProperty("user",adminuser);
            state.addProperty("state",1);
            JsonObject obj4 = client.getJSONValueByTypeIndex(prefix+"/"+project+"/"+Functions.TEMPLATES+"/"+Functions.TEMPLATES_OFFICIAL+"/"+ template,Functions.INDEX_IOT_TEMPLATESTATE,Functions.TYPE_IOT_TEMPLATE_STATE,state.toString(),null);

            array.add(obj1);
            array.add(obj2);
            array.add(obj3);
            array.add(obj4);
            array.add(obj5);
            array.add(obj6);

            return client.createHandleIFC2HANDLE(prefix+"/"+project+"/"+Functions.TEMPLATES+"/"+Functions.TEMPLATES_OFFICIAL+"/"+ template,values,Functions.randomKey(),adminuser,array);


        }catch(Exception e){

        }
        return false;
    }

    private ArrayList<IfcRoot> getIFCIds() {
        HashMap<TreePath, JCheckBoxTree.CheckedNode> aux = treeView.getTree().nodesCheckingState;
        Iterator<TreePath> lol = aux.keySet().iterator();
        ArrayList<IfcRoot> handles = new ArrayList<>();
        while (lol.hasNext()) {
            TreePath path = lol.next();
            if (aux.get(path).isSelected()) {

                String[] aux2 = path.getLastPathComponent().toString().split(" ");
                if (aux2.length == 2) {
                    //System.out.println("TREEPATH:"+path.getPath());
                    IfcRoot id = getIFCElement(path.getLastPathComponent());
                    handles.add(id);
                }
            }
        }
        return handles;
    }
    String project;
    private ArrayList<HandleType> getHandles() {
        HashMap<TreePath, JCheckBoxTree.CheckedNode> aux = treeView.getTree().nodesCheckingState;
        Iterator<TreePath> lol = aux.keySet().iterator();
        //System.out.println("------");

        ArrayList<HandleType> handles = new ArrayList<>();
        while (lol.hasNext()) {
            //System.out.println(lol.next().)
            TreePath path = lol.next();
            if (aux.get(path).isSelected()) {

                String[] aux2 = path.getLastPathComponent().toString().split(" ");
                if (aux2.length == 2) {
                    //System.out.println("TREEPATH:"+path.getPath());
                    Object[] aaa = new Object[path.getPath().length-1];
                    for(int i=1; i < path.getPath().length;i++)
                        aaa[i-1]=path.getPath()[i];
                    project = getHandlePath(new Object[]{path.getPath()[0]});
                    String handle = getHandlePath(aaa);

                    //System.out.println("handle:"+handle);
                    HandleType aa = new HandleType();

                    int a=existHandle(handle);
                    System.out.println("EXISTE:"+a);
                    if(a!=-1) {
                        aa.setHandle(IFC2Handle.handles.get(a).getHandle());
                        aa.setType(IFC2Handle.handles.get(a).getType());
                    }
                    else {
                        aa.setHandle(handle);
                    }
                    System.out.println("HANDLE:"+aa.toString());
                    handles.add(aa);
                    //DefaultMutableTreeNode selectedElement = (DefaultMutableTreeNode)path.getLastPathComponent();
                    //Object userObject = selectedElement.getUserObject();
                    //System.out.println("PATH:" + path.getLastPathComponent().toString() + "   STATE:" + aux.get(path).isSelected()+"   ALGO:"+aux.get(path).getName());

                }
            }
        }
        return handles;
    }

    public int existHandle(String h){
        for(int i=0; i < handles.size();i++){
            if(handles.get(i).getHandle().equals(h))
                return i;
        }
        return -1;
    }

    public IfcRoot getIFCElement(Object objects) {
        //String aux = line1.replaceAll("\\[","").replaceAll("\\]","").trim();
        //System.out.println(aux);
        String res = "";
        //for(int i=0; i < objects.length;i++){
        try {
            String[] par = objects.toString().split(" ");

            Integer id = Integer.parseInt(par[0].replaceAll("#", "").trim());
            Iterator<ClassInterface> lol = ifcModel.getIfcObjects().iterator();
            while (lol.hasNext()) {
                ClassInterface aux = lol.next();
                if (aux.getStepLineNumber() == id) {
                    IfcRoot aaa = (IfcRoot) aux;
                    //System.out.println("ENCONTRADO="+aaa.getName());
                        /*if(!res.isEmpty())
							res+="/";
						res+=aaa.getName().toString().replaceAll("\\s","");
						break;*/
                    return aaa;
                }
            }
            //System.out.println("TEST:"+ifcModel.);
        } catch (Exception e) {
            //e.printStackTrace();
            //System.out.println("ERROR:"+objects[i].toString());

        }
        //System.out.println(objects[i].toString());
        //}

        return null;
    }

    public String getHandlePath(Object[] objects) {
        //String aux = line1.replaceAll("\\[","").replaceAll("\\]","").trim();
        //System.out.println(aux);
        String res = "";
        for (int i = 0; i < objects.length; i++) {
            try {
                String[] par = objects[i].toString().split(" ");

                Integer id = Integer.parseInt(par[0].replaceAll("#", "").trim());
                Iterator<ClassInterface> lol = ifcModel.getIfcObjects().iterator();
                while (lol.hasNext()) {
                    ClassInterface aux = lol.next();
                    if (aux.getStepLineNumber() == id) {
                        IfcRoot aaa = (IfcRoot) aux;
                        //System.out.println("ENCONTRADO="+aaa.getName());
                        if (!res.isEmpty())
                            res += "/";
                        res += aaa.getName().toString().replaceAll("\\s", "").toLowerCase();
                        break;
                    }
                }
                //System.out.println("TEST:"+ifcModel.);
            } catch (Exception e) {
                //e.printStackTrace();
                //System.out.println("ERROR:"+objects[i].toString());
                if (!res.isEmpty())
                    res += "/";
                res += objects[i].toString().replaceAll("\\s", "").toLowerCase();
            }
            //System.out.println(objects[i].toString());
        }

        return res;
    }

    private JScrollPane getInfoPane() {
        infoPane = new JTextPane();
        infoPane.setEditable(false);
        StyledDocument doc = infoPane.getStyledDocument();
        addStylesToDocument(doc);
        scrollPane = new JScrollPane();
        scrollPane.setMinimumSize(new Dimension(150, 400));
        scrollPane.setMaximumSize(new Dimension(150, 400));
        scrollPane.setPreferredSize(new Dimension(150, 400));
        scrollPane.setViewportView(infoPane);
        return scrollPane;
    }

    private JProgressBar getApplicationProgressBar() {
        progressBar = new JProgressBar(0, 100);
        progressBar.setPreferredSize(new Dimension(600, 20));
        progressBar.setStringPainted(false);
        return progressBar;
    }

   /* private JMenuBar getApplicationMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        menuBar.add(fileMenu);
        fileMenu.setMnemonic('F');
        JMenuItem openItem = new JMenuItem("open");
        openItem.setMnemonic('o');
//		openItem.setIcon(new ImageIcon(new ImageIcon(openImageUrl).getImage()
//				.getScaledInstance(20, 20, Image.SCALE_SMOOTH)));
        openItem.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                loadFile();
            }
        });
        fileMenu.add(openItem);
        saveItem = new JMenuItem("save");
        saveItem.setEnabled(false);
        saveItem.setMnemonic('o');
//		saveItem.setIcon(new ImageIcon(new ImageIcon(saveImageUrl).getImage()
//				.getScaledInstance(20, 20, Image.SCALE_SMOOTH)));
        saveItem.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                saveFile();
            }
        });
       // fileMenu.add(saveItem);

        JMenu dataMenu = new JMenu("Data");
        dataMenu.setMnemonic('D');
        renameProjectItem = new JMenuItem("Rename Project");
        renameProjectItem.setMnemonic('R');
        renameProjectItem.setEnabled(false);
//		renameProjectItem.setIcon(new ImageIcon(new ImageIcon(editImageUrl)
//				.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH)));
        renameProjectItem.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                renameProject();
            }
        });
        dataMenu.add(renameProjectItem);
        //menuBar.add(dataMenu);

        JMenu infoMenu = new JMenu("Info");
        infoMenu.setMnemonic('I');
        JMenuItem aboutMenuItem = new JMenuItem("About");
        aboutMenuItem.setMnemonic('A');
//		aboutMenuItem.setIcon(new ImageIcon(new ImageIcon(aboutImageUrl)
//				.getImage().getScaledInstance(20, 20, Image.SCALE_SMOOTH)));
        aboutMenuItem.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane
                        .showMessageDialog(
                                IFC2Handle.this,
                                new String(
                                        "OPEN IFC JAVA TOOLBOX\nDemo Application\n\nCopyright: CCPL BY-NC-SA 3.0 (cc) 2008\nEike Tauscher, Jan Tulke\n\nhttp://www.openifctools.com"),
                                "About", JOptionPane.INFORMATION_MESSAGE);

            }
        });
        infoMenu.add(aboutMenuItem);
        //menuBar.add(infoMenu);
        return menuBar;
    }*/

    private void renameProject() {
        IfcProject project = ifcModel.getIfcProject();
        String newName = JOptionPane.showInputDialog(this, "new project name",
                project.getName().getDecodedValue());
        project.setName(new IfcLabel(newName, true));
        treeView.repaint();
    }

    private void loadFile() {

        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showOpenDialog(IFC2Handle.this) == JFileChooser.APPROVE_OPTION) {

            final File file = fileChooser.getSelectedFile();
            ifcModel = new IfcModel();
            ifcModel.addStepParserProgressListener(new StepParserProgressListener() {
                @Override
                public void progressActionPerformed(final ProgressEvent event) {
                    progressBar.setValue((int) event.getCurrentState());
                    progressBar.setStringPainted(true);
                    progressBar.setString(event.getMessage());
                }

                @Override
                protected void finalize() throws Throwable {
                    super.finalize();

                }
            });

            new Thread(new Runnable() {

                @Override
                public void run() {
                    long startTime = System.currentTimeMillis();
                    try {
                        if (file.getAbsolutePath().endsWith("ifc"))
                            ifcModel.readStepFile(file);
                        else ifcModel.readIfcZipFile(file);
                    } catch (Exception e) {
                        e.printStackTrace();
                        JOptionPane.showMessageDialog(IFC2Handle.this,
                                e.getMessage(), "Error",
                                JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                    long endTime = System.currentTimeMillis();
                    progressBar.setValue(0);
                    //IFC2Handle.this.setTitle(file.getName());
                    progressBar.setStringPainted(false);
                    treeView.setIfcModel(ifcModel);
                    //saveItem.setEnabled(true);
                    //renameProjectItem.setEnabled(true);
                    ifcinfo.setText(file.getName());
                    generateifcfile.setEnabled(true);
                    /*String[] info = {"*************************\n", "File:\n",
                            file.getName() + "\n\n", "Loading time:\n",
                            (endTime - startTime) / 1000 + " seconds\n\n",
                            "Number of elements:\n",
                            "" + ifcModel.getNumberOfElements() + "\n",
                            "*************************\n\n"};
                    String[] initStyles = {"bold", "bold", "regular", "bold",
                            "regular", "bold", "regular", "bold"};
                    StyledDocument doc = infoPane.getStyledDocument();
                    try {
                        for (int i = info.length - 1; i >= 0; i--) {
                            doc.insertString(0, info[i],
                                    doc.getStyle(initStyles[i]));
                        }
                    } catch (BadLocationException ble) {
                        System.err
                                .println("Couldn't insert initial text into text pane.");
                    }*/
                }
            }).start();
        }
    }

    private void saveFile() {
        JFileChooser fileChooser = new JFileChooser();
        if (fileChooser.showSaveDialog(IFC2Handle.this) == JFileChooser.APPROVE_OPTION) {

            final File file = fileChooser.getSelectedFile();
            ifcModel.addStepParserProgressListener(new StepParserProgressListener() {
                @Override
                public void progressActionPerformed(final ProgressEvent event) {
                    progressBar.setValue((int) event.getCurrentState());
                    progressBar.setStringPainted(true);
                    progressBar.setString(event.getMessage());
                }
            });

            new Thread(new Runnable() {

                @Override
                public void run() {
                    long startTime = System.currentTimeMillis();
                    try {
                        ifcModel.writeStepfile(file);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    long endTime = System.currentTimeMillis();
                    progressBar.setValue(0);
                    IFC2Handle.this.setTitle(file.getName());
                    progressBar.setStringPainted(false);
                    treeView.setIfcModel(ifcModel);
                    String[] info = {"*************************\n", "File:\n",
                            file.getName() + "\n\n", "Saving time:\n",
                            (endTime - startTime) / 1000 + " seconds\n\n",
                            "Number of elements:\n",
                            "" + ifcModel.getNumberOfElements() + "\n",
                            "*************************\n\n"};
                    String[] initStyles = {"bold", "bold", "regular", "bold",
                            "regular", "bold", "regular", "bold"};
                    StyledDocument doc = infoPane.getStyledDocument();
                    try {
                        for (int i = info.length - 1; i >= 0; i--) {
                            doc.insertString(0, info[i],
                                    doc.getStyle(initStyles[i]));
                        }
                    } catch (BadLocationException ble) {
                        System.err
                                .println("Couldn't insert initial text into text pane.");
                    }
                }
            }).start();
        }
    }

    protected void addStylesToDocument(StyledDocument doc) {
        Style def = StyleContext.getDefaultStyleContext().getStyle(
                StyleContext.DEFAULT_STYLE);

        Style regular = doc.addStyle("regular", def);
        StyleConstants.setFontFamily(def, "SansSerif");

        Style s = doc.addStyle("bold", regular);
        StyleConstants.setBold(s, true);
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }
        new IFC2Handle();
    }

}
