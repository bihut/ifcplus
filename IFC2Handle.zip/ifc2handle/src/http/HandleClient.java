package http;


import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import gui.Functions;
import net.handle.hdllib.Encoder;
import net.handle.hdllib.Util;
import org.apache.commons.codec.binary.Base64;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpDelete;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.TrustStrategy;
import org.apache.http.util.EntityUtils;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLSession;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static java.nio.charset.StandardCharsets.UTF_8;

/**
 * Created by bihut on 21/03/17.
 */
public class HandleClient {
    private String url;
    private HttpClient client;
    private HandleHeader header;
    private String sessionId;
    private String API_HANDLES ="/api/handles";
    private String API_EBIS ="/api/ifc";
    private String PREFIX,PROJECT;

    public boolean checkIfHandleExist(String handle){
        //System.out.println("HANDLE EXIST:"+handle);
        String res=this.GET(handle);
        //System.out.println("RES:"+res);
        //System.out.println("RES:"+res);
        if(res!=null)
            return true;
        return false;
    }

    public String checkIfIamAuthorised(String handle){
        String res=this.GET(handle);
        //System.out.println("RESA:"+res);

        if(res!=null) {
            try {
                JsonObject obj = new JsonParser().parse(res).getAsJsonObject();
                String value = obj.getAsJsonArray("values").get(0).getAsJsonObject().get("data").getAsJsonObject().get("value").getAsString();
                //System.out.println("VALUE:" + value);
                if(value!=null && !value.isEmpty())
                    return value;
            }catch(Exception e){

            }

        }
        return null;
    }
    public HandleClient(String mainurl,String prefix,String project){
        url = mainurl;
        this.PROJECT = project;
        this.PREFIX = prefix;
        header = new HandleHeader();
        try {
            client = getInsecureHttpClient();
            //((AbstractHttpClient) client).setHttpRequestRetryHandler(new DefaultHttpRequestRetryHandler(0, false));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String buildBasicAuthorizationString(String username, String password) {
        username=username.replaceAll("%","%25").replaceAll(":","%3A");
        password = password.replaceAll("%","%25").replaceAll(":","%3A");
        String credentials = username + ":" + password;
        return "Basic "+ Base64.encodeBase64String(credentials.getBytes(Charset.forName("UTF-8")));
    }


    public boolean authenticateByPrivateKey(String url,String handle,byte[] privateKey,int index){
        try{
            HttpGet getRequest = new HttpGet(this.url+url);
            String req1 = buildBasicAuthorizationString(index+":"+handle,"");
            getRequest.addHeader("Authorization",req1);
            HttpResponse response = client.execute(getRequest);

            Header[] headers=response.getAllHeaders();
            String res="";
            for(int i=0; i < headers.length;i++){
                if(headers[i].getValue().contains("nonce")){
                    res = headers[i].getValue();
                }
            }
            //System.out.println("RES:"+res);
            boolean aa=header.parseAll(res);

            if(aa){
                getRequest = new HttpGet(this.url+url);
                String hld = index+":"+handle;
                header.setId(hld);
                header.setType("HS_PUBKEY");
                header.setAlg("SHA256");
                header.initCNonce();
                PrivateKey privkey = Util.getPrivateKeyFromBytes(privateKey);
                byte[] serverNonce = java.util.Base64.getDecoder().decode(header.getNonce());
                byte[] clientNonce = java.util.Base64.getDecoder().decode(header.getCnonce());
                Signature signature = Signature.getInstance("SHA256withRSA");
                signature.initSign(privkey);
                signature.update(serverNonce);
                signature.update(clientNonce);
                byte[] sigBytes = signature.sign();
                String digestString =  java.util.Base64.getEncoder().encodeToString(sigBytes);
                header.setSignature(digestString);
                getRequest.addHeader("Authorization","Handle "+header.toString());
                response = client.execute(getRequest);
                if(response.getStatusLine().getStatusCode()!=200){
                    header.reset();
                }
                else return true;

            }

        }catch(Exception e){

        }
        return false;
    }

    public boolean authenticateByPrivateKey(String url,String handle,PrivateKey privateKey,int index){
        try{
            HttpGet getRequest = new HttpGet(this.url+url);
            String req1 = buildBasicAuthorizationString(index+":"+handle,"");
            getRequest.addHeader("Authorization",req1);
            HttpResponse response = client.execute(getRequest);

            Header[] headers=response.getAllHeaders();
            String res="";
            for(int i=0; i < headers.length;i++){

                if(headers[i].getValue().contains("nonce")){
                    res = headers[i].getValue();
                }
            }
            //System.out.println("RES:"+res);
            boolean aa=header.parseAll(res);

            if(aa){
                getRequest = new HttpGet(this.url+url);
                String hld = index+":"+handle;
                header.setId(hld);
                header.setType("HS_PUBKEY");
                header.setAlg("SHA256");
                header.initCNonce();

                //PrivateKey privkey = Util.getPrivateKeyFromFileWithPassphrase(new File(privatekeypath),passphrase);
                byte[] serverNonce = java.util.Base64.getDecoder().decode(header.getNonce());
                byte[] clientNonce = java.util.Base64.getDecoder().decode(header.getCnonce());
                Signature signature = Signature.getInstance("SHA256withRSA");
                signature.initSign(privateKey);
                signature.update(serverNonce);
                signature.update(clientNonce);
                byte[] sigBytes = signature.sign();
                String digestString =  java.util.Base64.getEncoder().encodeToString(sigBytes);
                header.setSignature(digestString);
                getRequest.addHeader("Authorization","Handle "+header.toString());
                response = client.execute(getRequest);
                if(response.getStatusLine().getStatusCode()!=200){
                    header.reset();
                }
                else return true;

            }

        }catch(Exception e){

        }
        return false;
    }

    public boolean authenticateByPrivateKey(String url,String handle,String privatekeypath,String passphrase,int index){
        try{
            HttpGet getRequest = new HttpGet(this.url+url);
            String req1 = buildBasicAuthorizationString(index+":"+handle,passphrase);
            getRequest.addHeader("Authorization",req1);
            HttpResponse response = client.execute(getRequest);

            Header[] headers=response.getAllHeaders();
            String res="";
            for(int i=0; i < headers.length;i++){
                System.out.println(headers[i].toString());
                if(headers[i].getValue().contains("nonce")){
                    res = headers[i].getValue();
                }
            }
            //System.out.println("RES:"+res);
            boolean aa=header.parseAll(res);

            if(aa){
                getRequest = new HttpGet(this.url+url);
                String hld = index+":"+handle;
                header.setId(hld);
                header.setType("HS_PUBKEY");
                header.setAlg("SHA256");
                header.initCNonce();

                PrivateKey privkey = Util.getPrivateKeyFromFileWithPassphrase(new File(privatekeypath),passphrase);
                byte[] serverNonce = java.util.Base64.getDecoder().decode(header.getNonce());
                byte[] clientNonce = java.util.Base64.getDecoder().decode(header.getCnonce());
                Signature signature = Signature.getInstance("SHA256withRSA");
                signature.initSign(privkey);
                signature.update(serverNonce);
                signature.update(clientNonce);
                byte[] sigBytes = signature.sign();
                String digestString =  java.util.Base64.getEncoder().encodeToString(sigBytes);
                header.setSignature(digestString);
                getRequest.addHeader("Authorization","Handle "+header.toString());
                response = client.execute(getRequest);
                if(response.getStatusLine().getStatusCode()!=200){
                    header.reset();
                }
                else return true;

            }

        }catch(Exception e){

        }
        return false;
    }
    public boolean authenticateBySecretKey(String url,String handle,String token,int index){
        try{
            HttpGet getRequest = new HttpGet(this.url+url);
            System.out.println("URL:"+this.url+url);
            String req1 = buildBasicAuthorizationString(index+":"+handle,token);
            System.out.println("REQ1:"+req1);
            getRequest.addHeader("Authorization",req1);
            HttpResponse response = client.execute(getRequest);


            Header[] headers=response.getAllHeaders();
            String res="";
            for(int i=0; i < headers.length;i++){
                System.out.println(headers[i].toString());
                if(headers[i].getValue().contains("nonce")){
                    res = headers[i].getValue();
                }
            }
            boolean aa=header.parseAll(res);

            if(aa){
                //System.out.println("SESIONID:"+header.getSessionid());
               // System.out.println("NONCE:"+header.getNonce());
                getRequest = new HttpGet(this.url+url);
                String hld = index+":"+handle;
                header.setId(hld);
                header.setType("HS_SECKEY");
                header.setAlg("SHA1");
                header.initCNonce();

                byte[] serverNonce = java.util.Base64.getDecoder().decode(header.getNonce());
                byte[] clientNonce = java.util.Base64.getDecoder().decode(header.getCnonce());
                byte[] passwordbytes = Encoder.encodeSecretKey(token.getBytes(UTF_8),true);
                ByteArrayOutputStream outputStream = new ByteArrayOutputStream( );
                outputStream.write(passwordbytes);
                outputStream.write(serverNonce);
                outputStream.write(clientNonce);
                outputStream.write(passwordbytes);
                byte[] bytesToDigest = outputStream.toByteArray();
                MessageDigest digester = MessageDigest.getInstance("SHA-1");
                digester.update(bytesToDigest);
                byte[] digestBytes = digester.digest();
                String digestString = java.util.Base64.getEncoder().encodeToString(digestBytes);
                //MSiTBIM.Utils.Functions.print("DIGEST:"+digestString);
                header.setSignature(digestString);

                /*System.out.println("HEADER:"+header.toString() + "NONCE:"+header.getNonce() +" PASSWORD:"+java.util.Base64
                .getEncoder().encodeToString(passwordbytes));*/
                System.out.println("AUTH:"+header.toString());
                getRequest.addHeader("Authorization","Handle "+header.toString());

                response = client.execute(getRequest);

                if(response.getStatusLine().getStatusCode()!=200){
                    header.reset();
                }
                else {
                    sessionId = header.getSessionid();
                    System.out.println("SESSIONID:"+sessionId +"   "+header.getSessionid());
                    return true;
                }
            }
        }catch(Exception e){

        }
        header.reset();
        return false;
    }

    public boolean sessionEnable(){
        System.out.println(sessionId +"   "+header.getSessionid());
        return (sessionId!= null && !sessionId.isEmpty() && header.getSessionid()!=null && !header.getSessionid().isEmpty());
    }
    public String GET(String url){
        if(header.getSessionid()==null || header.getSessionid().isEmpty())
            return null;
        //System.out.println("AQUI");
        String res=null;
        try{
              HttpGet get = new HttpGet(this.url+API_HANDLES+"/"+url);
            System.out.println("URL:"+this.url+API_HANDLES+"/"+url);
            get.addHeader("Authorization","Handle sessionId=\""+header.getSessionid()+"\"");
            HttpResponse response = client.execute(get);
            System.out.println("STATUSCODE0:"+response.getStatusLine().getStatusCode());
            if(response.getStatusLine().getStatusCode()==200){
                res= EntityUtils.toString(response.getEntity());

            }
            else response.getEntity().getContent().close();
        }catch(Exception e){
            System.out.println("ERROR:"+e.getMessage());
            e.printStackTrace();
            res = null;
        }

        return res;
    }




    public String GETEbis(String url){
        if(header.getSessionid()==null || header.getSessionid().isEmpty())
            return null;
        String res=null;
        try{
            /*String res="";
            if(parameters!=null && parameters.length>0 && parameters.length%2==0){
                res+="?";
                for(int i=0; i < parameters.length;i+=2){
                    res+=parameters[i]+"="+parameters[i+1];
                    if(i+1<parameters.length-1)
                        res+="&";
                }


            }*/

            HttpGet get = new HttpGet(this.url+API_EBIS+url);
            System.out.println("URL:"+this.url+API_EBIS+url);
            get.addHeader("Authorization","Handle sessionId=\""+header.getSessionid()+"\"");
            HttpResponse response = client.execute(get);
            res= EntityUtils.toString(response.getEntity());
            //if(response.getStatusLine().getStatusCode()==200){
                //res= EntityUtils.toString(response.getEntity());
            //}
            response.getEntity().getContent().close();
        }catch(Exception e){
            e.printStackTrace();
            res = null;
        }
        return res;
    }

    public String GETTemplate(String item){
        if(header.getSessionid()==null || header.getSessionid().isEmpty())
            return null;
        String res=null;
        try{
            /*String res="";
            if(parameters!=null && parameters.length>0 && parameters.length%2==0){
                res+="?";
                for(int i=0; i < parameters.length;i+=2){
                    res+=parameters[i]+"="+parameters[i+1];
                    if(i+1<parameters.length-1)
                        res+="&";
                }


            }*/

            HttpGet get = new HttpGet(this.url+API_EBIS+"?"+Functions.PARAM_TEMPLATE+"="+item);
            System.out.println(this.url+API_EBIS+"?getTemplate=sensor");
            get.addHeader("Authorization","Handle sessionId=\""+header.getSessionid()+"\"");
            HttpResponse response = client.execute(get);
            res= EntityUtils.toString(response.getEntity());
            //if(response.getStatusLine().getStatusCode()==200){
            //res= EntityUtils.toString(response.getEntity());
            //}
            response.getEntity().getContent().close();
        }catch(Exception e){
            e.printStackTrace();
            res = null;
        }
        return res;
    }

    public String POST(String url,String... values){
        if(header.getSessionid()==null || header.getSessionid().isEmpty())
            return null;
        try{
            HttpPost post = new HttpPost(this.url+url);
            post.addHeader("Authorization","Handle sessionid=\""+header.getSessionid()+"\"");
            if(values!=null && values.length>0 && values.length%2==0){
                List<NameValuePair> params = new ArrayList<NameValuePair>();
                for(int i=0; i < values.length;i+=2){
                    params.add(new BasicNameValuePair(values[i],values[i+1]));
                }
                post.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
            }
            HttpResponse response = client.execute(post);
            if(response.getStatusLine().getStatusCode()==200){
                return EntityUtils.toString(response.getEntity());
            }
        }catch(Exception e){

        }
        return null;
    }

    public static HttpClient getInsecureHttpClient() throws GeneralSecurityException {

        /*RequestConfig config = RequestConfig.custom()
                .setConnectTimeout(5 * 1000)
                .setConnectionRequestTimeout(5* 1000)
                .setSocketTimeout(5 * 1000).build();*/
        TrustStrategy trustStrategy = new TrustStrategy() {
            @Override
            public boolean isTrusted(X509Certificate[] chain, String authType) {
                return true;
            }
        };

        HostnameVerifier hostnameVerifier = new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {
                return true;
            }
        };

        return HttpClients.custom()
                .setSSLSocketFactory(new SSLConnectionSocketFactory(
                        new SSLContextBuilder().loadTrustMaterial(trustStrategy).build(),
                        hostnameVerifier))
                .build();
    }

    public boolean logout(String server){
        server = server+"/api/sessions/this";
        HttpDelete delete = new HttpDelete(server);
        //System.out.println("sessionid:"+sessionId);
        delete.addHeader("Authorization","Handle sessionId=\""+sessionId+"\"");
        try {
            HttpResponse res=client.execute(delete);
            //System.out.println(res.getStatusLine().getStatusCode());
            System.out.println("SERVER:"+server);

            if(res.getStatusLine().getStatusCode()==204) {
                sessionId = "";
                return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public JsonObject getJSONValueADMIN(int index, String handle, int index2, String permissions){
        /*
          var valueadmin = {};
        valueadmin['index'] = index;
        valueadmin['type'] = "HS_ADMIN";
        valueadmin['data'] = {
            "format": "admin",
            "value": {"handle": handle, "index": indexadmin, "permissions": permissions}
        };
        valueadmin['timestamp'] = new Date();
        //valueadmin['permissions']="1110";
        valueadmin['ttl'] = 86400;
        return valueadmin;
         */
        JsonObject obj = new JsonObject();
        obj.addProperty("index",index);
        //obj.addProperty("handle",handle);
        obj.addProperty("type","HS_ADMIN");
        JsonObject aux = new JsonObject();
        aux.addProperty("format","admin");
        JsonObject aux2 = new JsonObject();
        aux2.addProperty("handle",handle);
        aux2.addProperty("index",index2);
        aux2.addProperty("permissions",permissions);
        aux.add("value",aux2);
        obj.add("data",aux);
        Date date = new Date(System.currentTimeMillis());

        String formatted = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
        obj.addProperty("timestamp",formatted);
        obj.addProperty("ttl",86400);
        //valueadmin['timestamp'] = new Date();
        //valueadmin['permissions']="1110";
        //valueadmin['ttl'] = 86400;
        return obj;
    }

    public JsonObject getDefaultHSVLIST(String handle,int index){
        //JsonObject valueadmin1 = getJSONValueADMIN(101,gui.PREFIX+"/"+gui.PROJECT+"/superuser/pm",200,"111111110011");
        JsonObject valueadmin0 = new JsonObject();
        valueadmin0.addProperty("handle",handle);
        valueadmin0.addProperty("index",index);
        return valueadmin0;

        //JsonObject valueadmin3 = getJSONValueADMIN(103,gui.PREFIX+"/"+gui.PROJECT+"/users/"+gui.user,300,"111111110011");
        //JsonObject valueadmin4 = getJSONValueADMIN(104,handleid,200,"111111110011");
    }

    public JsonObject getJSONValueHSVLIST(int index, JsonArray values, int index2, String permissions){

        JsonObject obj = new JsonObject();
        obj.addProperty("index",index);
        //obj.addProperty("handle",handle);
        obj.addProperty("type","HS_VLIST");
        JsonObject aux = new JsonObject();
        aux.addProperty("format","vlist");

        aux.add("value",values);


        obj.add("data",aux);
        Date date = new Date(System.currentTimeMillis());

        String formatted = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
        obj.addProperty("timestamp",formatted);
        obj.addProperty("ttl",86400);

        return obj;
    }

    public JsonObject getJSONValueByTypeIndex(String handle, int index, String type, String value,String permissions){
        JsonObject obj = new JsonObject();
        obj.addProperty("index",index);
        obj.addProperty("type",type);
        //obj.addProperty("handle",handle);
        JsonObject obj2 = new JsonObject();
        obj2.addProperty("format","string");
        obj2.addProperty("value",value);
        obj.add("data",obj2);
        if(permissions==null)
            obj.addProperty("permissions","1100");
        else obj.addProperty("permissions",permissions);
        Date date = new Date(System.currentTimeMillis());

        String formatted = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
        obj.addProperty("timestamp",formatted);
        obj.addProperty("ttl",86400);
        return obj;
    }

    private JsonObject getJSONValueHSVLIST(String handle, int index, String type, JsonArray value){
        JsonObject obj = new JsonObject();
        obj.addProperty("index",index);
        obj.addProperty("type",type);
        //obj.addProperty("handle",handle);
        JsonObject obj2 = new JsonObject();
        obj2.addProperty("format","vlist");
        obj2.add("value",value);
        obj.add("data",obj2);
        obj.addProperty("permissions","1110");
        Date date = new Date(System.currentTimeMillis());

        String formatted = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date);
        obj.addProperty("timestamp",formatted);
        obj.addProperty("ttl",86400);
        return obj;
    }

    public boolean createHandleIFC2HANDLE(String handleid,JsonArray valueshs,String key,String admin,JsonArray values){
        if(header.getSessionid()==null || header.getSessionid().isEmpty())
            return false;
        boolean res=false;
        try{

            JsonObject valueadmin0 = getJSONValueADMIN(100,PREFIX+"/",300,"111111110011");
            JsonObject valueadmin1 = getJSONValueADMIN(101,handleid,200,"111111110011");
            JsonObject secretkey = getJSONValueByTypeIndex(handleid,300,"HS_SECKEY",new String(Encoder.encodeSecretKey(key.getBytes(),true)),null);
            JsonObject hs = getJSONValueHSVLIST(handleid,200,"HS_VLIST",valueshs);

            JsonArray array = new JsonArray();
            array.add(valueadmin0);
            array.add(valueadmin1);

            array.add(secretkey);
            array.add(hs);
            array.addAll(values);

            String hld = this.url+API_HANDLES+"/"+handleid;
            HttpPut put = new HttpPut(hld);
            put.addHeader("Authorization","Handle sessionId=\""+header.getSessionid()+"\"");

            JsonObject obj = new JsonObject();
            obj.addProperty("handle",handleid);
            obj.add("values",array);
            System.out.println("OBJ:"+obj.toString());
            StringEntity params =new StringEntity(obj.toString());
            params.setContentEncoding("UTF-8");
            params.setContentType("application/json");
            put.setEntity(params);


            HttpResponse response=client.execute(put);
            System.out.println("RESULT:"+response.getStatusLine().getStatusCode());
            if(response.getStatusLine().getStatusCode()==200 || response.getStatusLine().getStatusCode()==201) {
                res = true;
            }
            response.getEntity().getContent().close();


        }catch(Exception e){
            res = false;
            //System.out.println("_ERROR:"+e.getMessage());
        }
        return res;
    }

    public boolean createHandleIFC2HANDLENA(JsonArray values,String key,String admin){
        if(header.getSessionid()==null || header.getSessionid().isEmpty())
            return false;
        boolean res=false;
        try{

            JsonObject valueadmin0 = getJSONValueADMIN(100,PREFIX+"/",300,"111111110011");
            JsonObject valueadmin1 = getJSONValueADMIN(101,"0.NA/"+PREFIX,300,"111111110011");
            JsonObject valueadmin2 = getJSONValueADMIN(102,PREFIX+"/"+ Functions.CREATORS,200,"111111110011");
            JsonObject secretkey = getJSONValueByTypeIndex(PREFIX,300,"HS_SECKEY",key,null);
            JsonObject hs = getJSONValueHSVLIST(PREFIX,200,"HS_VLIST",values);
            JsonArray array = new JsonArray();
            array.add(valueadmin0);
            array.add(valueadmin1);
            array.add(valueadmin2);
            array.add(secretkey);
            array.add(getJSONValueByTypeIndex(PREFIX+"/",400,"IOT_EBIS","",null));
            array.add(hs);

            String hld = this.url+API_HANDLES+"/0.NA/"+PREFIX;
            HttpPut put = new HttpPut(hld);
            put.addHeader("Authorization","Handle sessionId=\""+header.getSessionid()+"\"");

            JsonObject obj = new JsonObject();
            obj.addProperty("handle","0.NA/"+PREFIX);
            obj.add("values",array);
            System.out.println("OBJ:"+obj.toString());
            StringEntity params =new StringEntity(obj.toString());
            params.setContentEncoding("UTF-8");
            params.setContentType("application/json");
            put.setEntity(params);


            HttpResponse response=client.execute(put);
            System.out.println("RESULT:"+response.getStatusLine().getStatusCode());
            System.out.println("RESULT2:"+response.getStatusLine().toString() +"  "+EntityUtils.toString(response.getEntity()));
            if(response.getStatusLine().getStatusCode()==200 || response.getStatusLine().getStatusCode()==201) {
                res = true;
            }
            response.getEntity().getContent().close();


        }catch(Exception e){
            res = false;
            //System.out.println("_ERROR:"+e.getMessage());
        }
        return res;
    }

    public boolean createHandleEBIS(String handleid,JsonArray values){
        if(header.getSessionid()==null || header.getSessionid().isEmpty())
            return false;
        boolean res=false;
        try{
            String hld = this.url+API_HANDLES+"/"+handleid;
            HttpPut put = new HttpPut(hld);
            put.addHeader("Authorization","Handle sessionId=\""+header.getSessionid()+"\"");

            JsonObject obj = new JsonObject();
            obj.addProperty("handle",handleid);
            obj.add("values",values);
            StringEntity params =new StringEntity(obj.toString());
            params.setContentEncoding("UTF-8");
            params.setContentType("application/json");
            put.setEntity(params);

            HttpResponse response=client.execute(put);
            System.out.println("RESULT:"+response.getStatusLine().getStatusCode());
            if(response.getStatusLine().getStatusCode()==200 || response.getStatusLine().getStatusCode()==201) {
                res = true;
            }
            response.getEntity().getContent().close();


        }catch(Exception e){
            res = false;
            //System.out.println("_ERROR:"+e.getMessage());
        }
        return res;
    }

    public boolean updateHandleEBISValueByIndex(String handleid,int index,JsonArray value){
        if(header.getSessionid()==null || header.getSessionid().isEmpty())
            return false;
        boolean res=false;
        try{
            String hld = this.url+API_HANDLES+"/"+handleid+"?index="+index;
            HttpPut put = new HttpPut(hld);
            System.out.println("HLD:"+hld);
            put.addHeader("Authorization","Handle sessionId=\""+header.getSessionid()+"\"");

            JsonObject obj = new JsonObject();
            obj.addProperty("handle",handleid);
            obj.add("values",value);
            StringEntity params =new StringEntity(obj.toString());
            params.setContentEncoding("UTF-8");
            params.setContentType("application/json");
            put.setEntity(params);

            HttpResponse response=client.execute(put);
            System.out.println("RESULT:"+response.getStatusLine().getStatusCode());
            if(response.getStatusLine().getStatusCode()==200 || response.getStatusLine().getStatusCode()==201) {
                res = true;
            }
            response.getEntity().getContent().close();


        }catch(Exception e){
            res = false;
            //System.out.println("_ERROR:"+e.getMessage());
        }
        return res;
    }


    public boolean updateIOTData(String handleid, String data){
        /*JsonObject valueadmin0 = getJSONValueADMIN(100,gui.PREFIX+"/ADMIN",300,"111111110011");
        JsonObject valueadmin1 = getJSONValueADMIN(101,gui.PREFIX+"/"+gui.PROJECT+"/superuser/pm",200,"111111110011");
        JsonObject valueadmin2 = getJSONValueADMIN(102,gui.PREFIX+"/"+gui.PROJECT+"/superuser/iso",200,"111111110011");
        JsonObject valueadmin3 = getJSONValueADMIN(103,gui.PREFIX+"/"+gui.PROJECT+"/users/"+user,300,"111111110011");
        JsonObject valueadmin4 = getJSONValueADMIN(104,handleid,200,"111111110011");
*/
        //JsonObject valueadmin4 = getJSONValueADMIN(200,gui.PREFIX+"/"+gui.PROJECT+"/users/"+user,300,"111111110011");
        JsonObject iotdata = getJSONValueByTypeIndex(handleid,850,"IOT_DATA",data,null);
        //JsonObject typesensitive = getJSONValueByTypeIndex(handleid,700,"IOT_SENSITIVE","1");
        //JsonObject typedevice = getJSONValueByTypeIndex(handleid,802,"IOT_TYPE","IOT_DATA");
        //JsonObject hs = getJSONValueByTypeIndex(handleid,200,"HS_VLIST","");
        JsonArray array = new JsonArray();

        /*array.add(valueadmin0);
        array.add(valueadmin1);
        array.add(valueadmin2);
        array.add(valueadmin3);
        array.add(valueadmin4);*/
        //array.add(typedevice);
        //array.add(typesensitive);
        array.add(iotdata);
       // array.add(hs);
        return updateHandleEBISValueByIndex(handleid,850,array);
    }


    public boolean createHandleIOTData(String handleid, String data,String user){
        JsonObject valueadmin0 = getJSONValueADMIN(100 ,PREFIX+"/ADMIN",300,"111111110011");
        JsonObject valueadmin1 = getJSONValueADMIN(101,PREFIX+"/"+PROJECT+"/superuser/pm",200,"111111110011");
        JsonObject valueadmin2 = getJSONValueADMIN(102,PREFIX+"/"+PROJECT+"/superuser/iso",200,"111111110011");
        JsonObject valueadmin3 = getJSONValueADMIN(103,PREFIX+"/"+PROJECT+"/users/"+user,300,"111111110011");
        JsonObject valueadmin4 = getJSONValueADMIN(104,handleid,200,"111111110011");

        //JsonObject valueadmin4 = getJSONValueADMIN(200,gui.PREFIX+"/"+gui.PROJECT+"/users/"+user,300,"111111110011");
        JsonObject iotdata = getJSONValueByTypeIndex(handleid,850,"IOT_DATA",data,null);
        JsonObject typesensitive = getJSONValueByTypeIndex(handleid,700,"IOT_SENSITIVE","1",null);
        JsonObject typedevice = getJSONValueByTypeIndex(handleid,802,"IOT_TYPE","IOT_DATA",null);
        JsonObject hs = getJSONValueByTypeIndex(handleid,200,"HS_VLIST","",null);
        JsonArray array = new JsonArray();

        array.add(valueadmin0);
        array.add(valueadmin1);
        array.add(valueadmin2);
        array.add(valueadmin3);
        array.add(valueadmin4);
        array.add(typedevice);
        array.add(typesensitive);
        array.add(iotdata);
        array.add(hs);
        return createHandleEBIS(handleid,array);
    }
    public boolean createHandleLoRaDevice(String handleid,String user){
        JsonObject valueadmin0 = getJSONValueADMIN(100,PREFIX+"/ADMIN",300,"111111110011");
        JsonObject valueadmin1 = getJSONValueADMIN(101,PREFIX+"/"+PROJECT+"/superuser/pm",200,"111111110011");
        JsonObject valueadmin2 = getJSONValueADMIN(102,PREFIX+"/"+PROJECT+"/superuser/iso",200,"111111110011");
        JsonObject valueadmin3 = getJSONValueADMIN(103,PREFIX+"/"+PROJECT+"/users/"+user,300,"111111110011");
        JsonObject valueadmin4 = getJSONValueADMIN(104,handleid,200,"111111110011");
        JsonObject typesensitive = getJSONValueByTypeIndex(handleid,700,"IOT_SENSITIVE","1",null);
        JsonObject typedevice = getJSONValueByTypeIndex(handleid,802,"IOT_TYPE","IOT_ENDNODELORA",null);
        JsonObject hs = getJSONValueByTypeIndex(handleid,200,"HS_VLIST","",null);
        JsonArray array = new JsonArray();

        array.add(valueadmin0);
        array.add(valueadmin1);
        array.add(valueadmin2);
        array.add(valueadmin3);
        array.add(valueadmin4);
        array.add(typedevice);
        array.add(typesensitive);
        array.add(hs);
        return createHandleEBIS(handleid,array);
        /*if(header.getSessionid()==null || header.getSessionid().isEmpty())
            return false;
        boolean res=false;
        try{
            HttpPut put = new HttpPut(this.url+API_HANDLES+"/"+handleid);
            System.out.println("URL0:"+this.url+API_HANDLES+"/"+handleid);
            put.addHeader("Authorization","Handle sessionId=\""+header.getSessionid()+"\"");

            JsonObject obj = new JsonObject();
            obj.addProperty("handle",handleid);
            JsonObject valueadmin0 = getJSONValueADMIN(100,gui.PREFIX+"/ADMIN",300,"111111110011");
            JsonObject valueadmin1 = getJSONValueADMIN(101,gui.PREFIX+"/"+gui.PROJECT+"/superuser/pm",200,"111111110011");
           JsonObject valueadmin2 = getJSONValueADMIN(102,gui.PREFIX+"/"+gui.PROJECT+"/superuser/iso",200,"111111110011");
           JsonObject typesensitive = getJSONValueByTypeIndex(handleid,700,"IOT_SENSITIVE","1");
           JsonObject typedevice = getJSONValueByTypeIndex(handleid,802,"IOT_TYPE","IOT_ENDNODELORA");
            JsonArray array = new JsonArray();

            array.add(valueadmin0);
            array.add(valueadmin1);
            array.add(valueadmin2);
            array.add(typedevice);
            array.add(typesensitive);

            obj.add("values",array);
            StringEntity params =new StringEntity(obj.toString());
            params.setContentEncoding("UTF-8");
            params.setContentType("application/json");
            put.setEntity(params);
            System.out.println("OBJ:"+EntityUtils.toString(put.getEntity()));
            System.out.println("Executing request " + put.getRequestLine());

            HttpResponse response=client.execute(put);
            System.out.println("RESULT:"+response.getStatusLine().getStatusCode());
            if(response.getStatusLine().getStatusCode()==200) {
                res = true;
            }
            response.getEntity().getContent().close();


        }catch(Exception e){
            res = false;
            System.out.println("_ERROR:"+e.getMessage());
        }
        return res;*/
    }

}
