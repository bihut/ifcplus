package http;


import java.util.Base64;
import java.util.Random;

/**
 * Created by bihut on 17/03/17.
 */
public class HandleHeader {
    private String sessionid;
    private String id;
    private String type;
    private String cnonce;
    private String nonce;
    private String alg;
    private String signature;

    private boolean parseSessionid(String line){
        String[] aux = line.split(",");
        for(int i=0; i < aux[i].length();i++){
            if(aux[i].contains("sessionId")){
                String aa = aux[i].trim();
                sessionid = aa.split("=")[1];
                sessionid = sessionid.trim();
                return true;
            }
        }
        return false;
    }
    public HandleHeader(){

    }
    public void reset(){
        sessionid = id = type = cnonce = nonce = alg = signature = "";
    }
    public boolean parseAll(String line){
        boolean res=true;
        String[] aux = line.split(",");
        //System.out.println("SIZE:"+aux.length);
        for(int i=0; i < aux.length;i++){
            if(aux[i].contains("sessionId")){
                String aa = aux[i].trim();
                sessionid = aa.split("=")[1];
                sessionid= sessionid.replaceAll("\"","");
                sessionid = sessionid.trim();


            }
            else if(aux[i].contains("nonce")){

                String aa = aux[i].trim();

                nonce = aa.replace("nonce=","");
                nonce = nonce.replaceAll("\"","");
                nonce = nonce.trim();

            }
        }
        return res;
    }

    public String getNonce() {
        return nonce;
    }

    public void setNonce(String nonce) {
        this.nonce = nonce;
    }

    public String getSessionid() {
        return sessionid;
    }

    public void setSessionid(String sessionid) {
        this.sessionid = sessionid;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
        //this.id = id.replaceAll("%","%25").replaceAll(":","%3A");
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getCnonce() {
        return cnonce;
    }

    public void initCNonce(){
        byte[] b = new byte[16];
        new Random().nextBytes(b);
        /*setCnonce(Base64.getEncoder().encode(b));*/
        //Base64.getDecoder().decode(header.getNonce());
        //setCnonce(Base64.getDecoder().de);
        //setCnonce(net.cnri.util.StringUtils.encode);
        setCnonce(Base64.getEncoder().encodeToString(b));
        //setCnonce(org.apache.commons.codec.binary.Base64.encodeBase64String(b));
    }
    public void setCnonce(String cnonce) {
        this.cnonce = cnonce;
    }

    public String getAlg() {
        return alg;
    }

    public void setAlg(String alg) {
        this.alg = alg;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(String signature) {
        this.signature = signature;
    }

    @Override
    public String toString() {
        String res="";
        //res+="version=\"0\",";
        res+="sessionId=\""+ sessionid+ "\", ";
        res+="id=\""+id+"\", ";
        res+="type=\""+type+"\", ";
        res+="cnonce=\""+cnonce+"\", ";
        res+="alg=\""+alg+"\", ";
        res+="signature=\""+signature+"\" ";
        return res;
    }
}
